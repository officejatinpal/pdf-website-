<?php
class ApiFileController {
    public function download() {
        $file = basename($_GET['file'] ?? '');
        $type = $_GET['type'] ?? 'processed';
        if (!$file) jsonResponse(['success'=>false,'message'=>'File not specified'], 400);

        // Only allow safe filenames
        if (!preg_match('/^[a-zA-Z0-9_\-.]+$/', $file)) {
            jsonResponse(['success'=>false,'message'=>'Invalid filename'], 400);
        }

        $dir = $type === 'temp' ? UPLOAD_TEMP_DIR : UPLOAD_PROCESSED_DIR;
        $filePath = $dir . $file;

        if (!file_exists($filePath)) {
            jsonResponse(['success'=>false,'message'=>'File not found or expired'], 404);
        }

        $mimeType = mime_content_type($filePath);
        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($filePath));
        header('X-Content-Type-Options: nosniff');
        readfile($filePath);
        exit;
    }

    public function delete() {
        $file = basename($_POST['file'] ?? '');
        if (!$file || !preg_match('/^[a-zA-Z0-9_\-.]+$/', $file)) {
            jsonResponse(['success'=>false,'message'=>'Invalid filename']);
        }
        $paths = [UPLOAD_TEMP_DIR . $file, UPLOAD_PROCESSED_DIR . $file];
        foreach ($paths as $path) {
            if (file_exists($path)) { unlink($path); }
        }
        jsonResponse(['success'=>true,'message'=>'File deleted']);
    }
}
