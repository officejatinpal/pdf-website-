<?php
class PdfController {
    private $toolModel;

    public function __construct() {
        $this->toolModel = new Tool();
    }

    public function mergePage() {
        $tool = $this->toolModel->findBySlug('pdf-merge');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'merge']);
    }

    public function splitPage() {
        $tool = $this->toolModel->findBySlug('pdf-split');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'split']);
    }

    public function compressPage() {
        $tool = $this->toolModel->findBySlug('pdf-compress');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'compress']);
    }

    public function rotatePage() {
        $tool = $this->toolModel->findBySlug('pdf-rotate');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'rotate']);
    }

    public function pdfToWordPage() {
        $tool = $this->toolModel->findBySlug('pdf-to-word');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'pdf-to-word']);
    }

    public function wordToPdfPage() {
        $tool = $this->toolModel->findBySlug('word-to-pdf');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'word-to-pdf']);
    }

    public function jpgToPdfPage() {
        $tool = $this->toolModel->findBySlug('jpg-to-pdf');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'jpg-to-pdf']);
    }

    public function pdfToJpgPage() {
        $tool = $this->toolModel->findBySlug('pdf-to-jpg');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'pdf-to-jpg']);
    }

    public function lockPdfPage() {
        $tool = $this->toolModel->findBySlug('lock-pdf');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'lock']);
    }

    public function unlockPdfPage() {
        $tool = $this->toolModel->findBySlug('unlock-pdf');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'unlock']);
    }

    public function watermarkPage() {
        $tool = $this->toolModel->findBySlug('add-watermark');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'watermark']);
    }

    public function ocrPage() {
        $tool = $this->toolModel->findBySlug('pdf-ocr');
        $relatedTools = $this->getRelated('pdf');
        $this->render('tools/pdf-tool', ['tool' => $tool, 'relatedTools' => $relatedTools, 'toolAction' => 'ocr']);
    }

    private function getRelated($category) {
        return $this->toolModel->getAll($category);
    }

    private function render($view, $data = [], $layout = 'main') {
        extract($data);
        $pageTitle = ($tool['meta_title'] ?? $tool['name']) . ' - ' . APP_NAME;
        $metaDesc = $tool['meta_description'] ?? $tool['description'];
        ob_start();
        require __DIR__ . "/../Views/{$view}.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/{$layout}.php";
    }
}
