<?php
class ApiImageController {
    private $toolModel;

    public function __construct() {
        $this->toolModel = new Tool();
    }

    public function resize() {
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);
        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_IMAGE);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $width = intval($_POST['width'] ?? 0);
        $height = intval($_POST['height'] ?? 0);
        $maintainAspect = $_POST['maintain_aspect'] ?? '1';

        if (!$width && !$height) jsonResponse(['success'=>false,'message'=>'Width ya height required hai']);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        if (!$saved) jsonResponse(['success'=>false,'message'=>'File save error']);

        $image = $this->loadImage($saved['path'], $validation['mime_type']);
        if (!$image) jsonResponse(['success'=>false,'message'=>'Invalid image file']);

        $origWidth = imagesx($image);
        $origHeight = imagesy($image);

        if ($maintainAspect === '1') {
            if ($width && !$height) $height = intval($origHeight * ($width / $origWidth));
            elseif ($height && !$width) $width = intval($origWidth * ($height / $origHeight));
        }

        $newImage = imagecreatetruecolor($width, $height);
        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $width, $height, $origWidth, $origHeight);

        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        $outputName = 'resized_' . uniqid() . '.' . $ext;
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;

        $this->saveImage($newImage, $outputPath, $validation['mime_type']);
        imagedestroy($image);
        imagedestroy($newImage);

        $tool = $this->toolModel->findBySlug('resize-image');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'resized.' . $ext,'width'=>$width,'height'=>$height]);
    }

    public function compress() {
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);
        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_IMAGE);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $quality = intval($_POST['quality'] ?? 80);
        if ($quality < 1 || $quality > 100) $quality = 80;

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        $image = $this->loadImage($saved['path'], $validation['mime_type']);
        if (!$image) jsonResponse(['success'=>false,'message'=>'Invalid image']);

        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        $outputName = 'compressed_' . uniqid() . '.' . $ext;
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;

        $this->saveImage($image, $outputPath, $validation['mime_type'], $quality);
        imagedestroy($image);

        $originalSize = filesize($saved['path']);
        $compressedSize = filesize($outputPath);
        $reduction = round((1 - $compressedSize / $originalSize) * 100, 1);

        $tool = $this->toolModel->findBySlug('compress-image');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse([
            'success' => true,
            'download_url' => $downloadUrl,
            'filename' => 'compressed.' . $ext,
            'original_size' => FileHelper::formatSize($originalSize),
            'compressed_size' => FileHelper::formatSize($compressedSize),
            'reduction' => $reduction . '%'
        ]);
    }

    public function bgRemove() {
        // This requires an external AI API like remove.bg
        $apiKey = defined('REMOVEBG_API_KEY') ? REMOVEBG_API_KEY : '';
        if (!$apiKey) {
            jsonResponse(['success'=>false,'message'=>'Background remove ke liye remove.bg API key configure karein']);
        }
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_IMAGE);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://api.remove.bg/v1.0/removebg',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => ['image_file' => new CURLFile($saved['path']), 'size' => 'auto'],
            CURLOPT_HTTPHEADER => ['X-Api-Key: ' . $apiKey],
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            jsonResponse(['success'=>false,'message'=>'Background removal failed. API error.']);
        }

        $outputName = 'nobg_' . uniqid() . '.png';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;
        file_put_contents($outputPath, $response);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'no_background.png']);
    }

    private function loadImage($path, $mimeType) {
        return match($mimeType) {
            'image/jpeg' => imagecreatefromjpeg($path),
            'image/png' => imagecreatefrompng($path),
            'image/gif' => imagecreatefromgif($path),
            'image/webp' => imagecreatefromwebp($path),
            default => null
        };
    }

    private function saveImage($image, $path, $mimeType, $quality = 90) {
        match($mimeType) {
            'image/jpeg' => imagejpeg($image, $path, $quality),
            'image/png' => imagepng($image, $path, intval(9 - ($quality / 10))),
            'image/gif' => imagegif($image, $path),
            'image/webp' => imagewebp($image, $path, $quality),
            default => imagejpeg($image, $path, $quality)
        };
    }
}
