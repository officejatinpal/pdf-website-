<?php
class PageController {
    public function privacy() {
        $this->render('pages/privacy', ['pageTitle' => 'Privacy Policy - ' . APP_NAME, 'metaDesc' => 'Hamari Privacy Policy']);
    }
    public function terms() {
        $this->render('pages/terms', ['pageTitle' => 'Terms & Conditions - ' . APP_NAME, 'metaDesc' => 'Hamare Terms & Conditions']);
    }
    public function about() {
        $this->render('pages/about', ['pageTitle' => 'About Us - ' . APP_NAME, 'metaDesc' => 'Hamare baare mein']);
    }
    public function contact() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $db = Database::getInstance();
            $db->insert('contact_messages', [
                'name' => htmlspecialchars($_POST['name'] ?? ''),
                'email' => filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL),
                'subject' => htmlspecialchars($_POST['subject'] ?? ''),
                'message' => htmlspecialchars($_POST['message'] ?? ''),
                'ip_address' => $_SERVER['REMOTE_ADDR'],
            ]);
            jsonResponse(['success' => true, 'message' => 'Message bhej diya gaya! Hum jald hi contact karenge.']);
        }
        $this->render('pages/contact', ['pageTitle' => 'Contact - ' . APP_NAME, 'metaDesc' => 'Humse sampark karein']);
    }
    private function render($view, $data = []) {
        extract($data);
        ob_start();
        $viewFile = __DIR__ . "/../Views/{$view}.php";
        if (file_exists($viewFile)) require $viewFile;
        else echo '<div class="container section"><h1>' . ($data['pageTitle'] ?? 'Page') . '</h1><p>Yeh page jald available hoga.</p></div>';
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/main.php";
    }
}
