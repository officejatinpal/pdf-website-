<?php
class BlogController {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function index() {
        $posts = $this->db->fetchAll(
            "SELECT id, title, slug, excerpt, featured_image, category, published_at 
             FROM blog_posts WHERE status = 'published' ORDER BY published_at DESC"
        );
        $this->render('blog/index', ['posts' => $posts, 'pageTitle' => 'Blog - ' . APP_NAME, 'metaDesc' => 'PDF, Image tools tips aur tutorials']);
    }

    public function show($slug) {
        $post = $this->db->fetch(
            "SELECT * FROM blog_posts WHERE slug = ? AND status = 'published'", [$slug]
        );
        if (!$post) { http_response_code(404); echo '404 Not Found'; return; }
        $this->db->query("UPDATE blog_posts SET views = views + 1 WHERE id = ?", [$post['id']]);
        $related = $this->db->fetchAll(
            "SELECT id, title, slug, featured_image FROM blog_posts WHERE status='published' AND id != ? AND category = ? LIMIT 3",
            [$post['id'], $post['category']]
        );
        $this->render('blog/show', ['post' => $post, 'related' => $related,
            'pageTitle' => ($post['meta_title'] ?? $post['title']) . ' - ' . APP_NAME,
            'metaDesc' => $post['meta_description'] ?? $post['excerpt']]);
    }

    private function render($view, $data = []) {
        extract($data);
        ob_start();
        require __DIR__ . "/../Views/{$view}.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/main.php";
    }
}
