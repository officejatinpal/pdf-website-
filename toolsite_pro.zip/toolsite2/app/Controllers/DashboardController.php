<?php
class DashboardController {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        if (!SessionHelper::isLoggedIn()) redirect('/login');
    }

    public function index() {
        $userId = SessionHelper::userId();
        $recentUsage = $this->db->fetchAll(
            "SELECT tu.*, t.name as tool_name, t.icon FROM tool_usage tu 
             LEFT JOIN tools t ON tu.tool_id = t.id 
             WHERE tu.user_id = ? ORDER BY tu.created_at DESC LIMIT 10",
            [$userId]
        );
        $favoriteTools = $this->db->fetchAll(
            "SELECT t.* FROM user_favorites uf JOIN tools t ON uf.tool_id = t.id WHERE uf.user_id = ?",
            [$userId]
        );
        $totalFiles = $this->db->fetch("SELECT COUNT(*) as cnt FROM file_uploads WHERE user_id = ?", [$userId])['cnt'];
        $totalTools = $this->db->fetch("SELECT COUNT(*) as cnt FROM tool_usage WHERE user_id = ?", [$userId])['cnt'];
        $user = SessionHelper::user();
        $data = compact('recentUsage', 'favoriteTools', 'totalFiles', 'totalTools', 'user');
        $this->render('dashboard/index', $data);
    }

    public function history() {
        $userId = SessionHelper::userId();
        $history = $this->db->fetchAll(
            "SELECT tu.*, t.name as tool_name FROM tool_usage tu 
             LEFT JOIN tools t ON tu.tool_id = t.id 
             WHERE tu.user_id = ? ORDER BY tu.created_at DESC",
            [$userId]
        );
        $this->render('dashboard/history', ['history' => $history]);
    }

    public function favorites() {
        $userId = SessionHelper::userId();
        $favorites = $this->db->fetchAll(
            "SELECT t.* FROM user_favorites uf JOIN tools t ON uf.tool_id = t.id WHERE uf.user_id = ?",
            [$userId]
        );
        $this->render('dashboard/favorites', ['favorites' => $favorites]);
    }

    private function render($view, $data = []) {
        extract($data);
        $pageTitle = 'Dashboard - ' . APP_NAME;
        $metaDesc = 'Your personal dashboard';
        ob_start();
        require __DIR__ . "/../Views/{$view}.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/main.php";
    }
}
