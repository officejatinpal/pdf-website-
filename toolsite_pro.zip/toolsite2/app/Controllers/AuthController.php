<?php
class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function loginPage() {
        if (SessionHelper::isLoggedIn()) redirect('/dashboard');
        $this->render('auth/login', [], 'auth');
    }

    public function registerPage() {
        if (SessionHelper::isLoggedIn()) redirect('/dashboard');
        $this->render('auth/register', [], 'auth');
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/login');
        if (!SessionHelper::verifyCsrf($_POST['csrf_token'] ?? '')) {
            jsonResponse(['success' => false, 'message' => 'Invalid request']);
        }
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';
        if (!$email || !$password) {
            jsonResponse(['success' => false, 'message' => 'Email aur password required hai']);
        }
        $user = $this->userModel->findByEmail($email);
        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            jsonResponse(['success' => false, 'message' => 'Email ya password galat hai']);
        }
        if (!$user['is_active']) {
            jsonResponse(['success' => false, 'message' => 'Aapka account deactivate hai']);
        }
        SessionHelper::login($user);
        $this->userModel->updateLastLogin($user['id']);
        jsonResponse(['success' => true, 'redirect' => APP_URL . '/dashboard']);
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/register');
        if (!SessionHelper::verifyCsrf($_POST['csrf_token'] ?? '')) {
            jsonResponse(['success' => false, 'message' => 'Invalid request']);
        }
        $name = htmlspecialchars(trim($_POST['name'] ?? ''));
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';
        if (!$name || !$email || !$password) {
            jsonResponse(['success' => false, 'message' => 'Saari fields required hain']);
        }
        if (strlen($password) < 8) {
            jsonResponse(['success' => false, 'message' => 'Password kam se kam 8 characters ka hona chahiye']);
        }
        if ($this->userModel->findByEmail($email)) {
            jsonResponse(['success' => false, 'message' => 'Yeh email already registered hai']);
        }
        $userId = $this->userModel->create([
            'name' => $name,
            'email' => $email,
            'password' => $this->userModel->hashPassword($password),
            'is_verified' => 1,
        ]);
        $user = $this->userModel->findById($userId);
        SessionHelper::login($user);
        jsonResponse(['success' => true, 'redirect' => APP_URL . '/dashboard']);
    }

    public function logout() {
        SessionHelper::logout();
        redirect('/');
    }

    private function render($view, $data = [], $layout = 'auth') {
        extract($data);
        $pageTitle = APP_NAME . ' - Login / Register';
        $metaDesc = 'Login or Register to access your dashboard';
        ob_start();
        require __DIR__ . "/../Views/{$view}.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/{$layout}.php";
    }
}
