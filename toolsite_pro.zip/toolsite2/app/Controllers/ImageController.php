<?php
class ImageController {
    private $toolModel;

    public function __construct() {
        $this->toolModel = new Tool();
    }

    public function resizePage() { $this->renderTool('resize-image', 'resize'); }
    public function compressPage() { $this->renderTool('compress-image', 'compress'); }
    public function cropPage() { $this->renderTool('crop-image', 'crop'); }
    public function bgRemoverPage() { $this->renderTool('bg-remover', 'bg-remove'); }
    public function imageToPdfPage() { $this->renderTool('image-to-pdf', 'image-to-pdf'); }
    public function jpgToPngPage() { $this->renderTool('jpg-to-png', 'jpg-to-png'); }
    public function pngToJpgPage() { $this->renderTool('png-to-jpg', 'png-to-jpg'); }

    private function renderTool($slug, $action) {
        $tool = $this->toolModel->findBySlug($slug);
        $relatedTools = $this->toolModel->getAll('image');
        $toolAction = $action;
        $pageTitle = ($tool['meta_title'] ?? $tool['name']) . ' - ' . APP_NAME;
        $metaDesc = $tool['meta_description'] ?? $tool['description'];
        ob_start();
        require __DIR__ . "/../Views/tools/image-tool.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/main.php";
    }
}
