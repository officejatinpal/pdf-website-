<?php
class HomeController {
    private $toolModel;
    private $db;

    public function __construct() {
        $this->toolModel = new Tool();
        $this->db = Database::getInstance();
    }

    public function index() {
        $popularTools = $this->toolModel->getPopular(12);
        $pdfTools = $this->toolModel->getAll('pdf');
        $imageTools = $this->toolModel->getAll('image');
        $faqs = $this->db->fetchAll("SELECT * FROM faqs WHERE tool_id IS NULL AND is_active = 1 ORDER BY sort_order");
        $reviews = $this->db->fetchAll("SELECT * FROM reviews WHERE is_approved = 1 ORDER BY created_at DESC LIMIT 6");
        $blogs = $this->db->fetchAll("SELECT id, title, slug, excerpt, featured_image, published_at FROM blog_posts WHERE status = 'published' ORDER BY published_at DESC LIMIT 3");
        
        $data = compact('popularTools', 'pdfTools', 'imageTools', 'faqs', 'reviews', 'blogs');
        $this->render('pages/home', $data, 'main');
    }

    private function render($view, $data = [], $layout = 'main') {
        extract($data);
        $pageTitle = APP_NAME . ' - Free Online PDF & Image Tools';
        $metaDesc = 'Free online tools for PDF, Image, and Document conversion. Merge PDF, Compress Image, Convert files and much more - 100% free!';
        ob_start();
        require __DIR__ . "/../Views/{$view}.php";
        $content = ob_get_clean();
        require __DIR__ . "/../Views/layouts/{$layout}.php";
    }
}
