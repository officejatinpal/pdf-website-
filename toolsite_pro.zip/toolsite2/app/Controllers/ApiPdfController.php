<?php
class ApiPdfController {
    private $db;
    private $toolModel;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->toolModel = new Tool();
    }

    public function merge() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success'=>false,'message'=>'Method not allowed'], 405);
        if (empty($_FILES['files'])) jsonResponse(['success'=>false,'message'=>'Files required hain']);
        
        $uploadedPaths = [];
        $fileCount = count($_FILES['files']['name']);
        if ($fileCount < 2) jsonResponse(['success'=>false,'message'=>'Kam se kam 2 PDF files chahiye']);
        if ($fileCount > 20) jsonResponse(['success'=>false,'message'=>'Maximum 20 files allowed hain']);

        for ($i = 0; $i < $fileCount; $i++) {
            $file = [
                'name' => $_FILES['files']['name'][$i],
                'type' => $_FILES['files']['type'][$i],
                'tmp_name' => $_FILES['files']['tmp_name'][$i],
                'error' => $_FILES['files']['error'][$i],
                'size' => $_FILES['files']['size'][$i],
            ];
            $validation = FileHelper::validateUpload($file, ALLOWED_PDF);
            if (!$validation['success']) {
                jsonResponse(['success'=>false,'message'=>'File ' . ($i+1) . ': ' . $validation['message']]);
            }
            $saved = FileHelper::saveUploadedFile($file, UPLOAD_TEMP_DIR);
            if (!$saved) jsonResponse(['success'=>false,'message'=>'File save karne mein error']);
            $uploadedPaths[] = $saved['path'];
            
            // Save to DB
            $this->db->insert('file_uploads', [
                'user_id' => SessionHelper::userId(),
                'session_id' => session_id(),
                'original_name' => $file['name'],
                'stored_name' => $saved['stored_name'],
                'file_path' => $saved['path'],
                'file_size' => $file['size'],
                'mime_type' => $validation['mime_type'],
                'file_type' => 'pdf',
                'upload_ip' => $_SERVER['REMOTE_ADDR'],
                'expires_at' => date('Y-m-d H:i:s', time() + FILE_LIFETIME),
            ]);
        }

        // Merge PDFs using Ghostscript (must be installed on server)
        $outputName = 'merged_' . uniqid() . '.pdf';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;
        
        $inputFiles = implode(' ', array_map('escapeshellarg', $uploadedPaths));
        $cmd = "gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=" . escapeshellarg($outputPath) . " " . $inputFiles . " 2>&1";
        exec($cmd, $output, $returnCode);

        if ($returnCode !== 0 || !file_exists($outputPath)) {
            // Fallback: try pdftk
            $cmd2 = "pdftk " . $inputFiles . " cat output " . escapeshellarg($outputPath) . " 2>&1";
            exec($cmd2, $output2, $returnCode2);
        }

        if (!file_exists($outputPath)) {
            jsonResponse(['success'=>false,'message'=>'PDF merge failed. Server par Ghostscript ya pdftk install karein.']);
        }

        $tool = $this->toolModel->findBySlug('pdf-merge');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'merged.pdf','size'=>FileHelper::formatSize(filesize($outputPath))]);
    }

    public function compress() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success'=>false,'message'=>'Method not allowed'], 405);
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_PDF);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        if (!$saved) jsonResponse(['success'=>false,'message'=>'File save error']);

        $quality = $_POST['quality'] ?? 'screen'; // screen, ebook, printer, prepress
        $allowedQuality = ['screen', 'ebook', 'printer', 'prepress'];
        if (!in_array($quality, $allowedQuality)) $quality = 'screen';

        $outputName = 'compressed_' . uniqid() . '.pdf';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;
        
        $cmd = "gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/" . $quality . 
               " -dNOPAUSE -dQUIET -dBATCH -sOutputFile=" . escapeshellarg($outputPath) . 
               " " . escapeshellarg($saved['path']) . " 2>&1";
        exec($cmd, $output, $returnCode);

        if (!file_exists($outputPath)) {
            jsonResponse(['success'=>false,'message'=>'Compression failed. Server par Ghostscript install karein.']);
        }

        $originalSize = filesize($saved['path']);
        $compressedSize = filesize($outputPath);
        $reduction = round((1 - $compressedSize / $originalSize) * 100, 1);

        $tool = $this->toolModel->findBySlug('pdf-compress');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse([
            'success' => true,
            'download_url' => $downloadUrl,
            'filename' => 'compressed.pdf',
            'original_size' => FileHelper::formatSize($originalSize),
            'compressed_size' => FileHelper::formatSize($compressedSize),
            'reduction' => $reduction . '%'
        ]);
    }

    public function split() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success'=>false,'message'=>'Method not allowed'], 405);
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_PDF);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        if (!$saved) jsonResponse(['success'=>false,'message'=>'File save error']);

        $splitType = $_POST['split_type'] ?? 'all'; // all, range, interval
        $pages = $_POST['pages'] ?? '';

        $outputDir = UPLOAD_PROCESSED_DIR . 'split_' . uniqid() . '/';
        mkdir($outputDir, 0755, true);

        if ($splitType === 'all') {
            $cmd = "pdftk " . escapeshellarg($saved['path']) . " burst output " . escapeshellarg($outputDir . "page_%04d.pdf") . " 2>&1";
        } else {
            // specific pages e.g. "1-3" or "1,3,5"
            $cmd = "pdftk " . escapeshellarg($saved['path']) . " cat " . escapeshellarg($pages) . " output " . escapeshellarg($outputDir . "split.pdf") . " 2>&1";
        }
        exec($cmd, $output, $returnCode);

        $splitFiles = glob($outputDir . '*.pdf');
        if (empty($splitFiles)) {
            jsonResponse(['success'=>false,'message'=>'Split failed. Server par pdftk install karein.']);
        }

        // Create zip
        $zipName = 'split_pages_' . uniqid() . '.zip';
        $zipPath = UPLOAD_PROCESSED_DIR . $zipName;
        FileHelper::createZip($splitFiles, $zipPath);

        $tool = $this->toolModel->findBySlug('pdf-split');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($zipName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'split_pages.zip','pages_count'=>count($splitFiles)]);
    }

    public function rotate() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['success'=>false,'message'=>'Method not allowed'], 405);
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_PDF);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        $angle = intval($_POST['angle'] ?? 90);
        if (!in_array($angle, [90, 180, 270])) $angle = 90;

        $outputName = 'rotated_' . uniqid() . '.pdf';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;
        $rotation = ['90' => 'east', '180' => 'south', '270' => 'west'][$angle];
        
        $cmd = "pdftk " . escapeshellarg($saved['path']) . " rotate 1-end" . $rotation . " output " . escapeshellarg($outputPath) . " 2>&1";
        exec($cmd, $output, $returnCode);

        if (!file_exists($outputPath)) jsonResponse(['success'=>false,'message'=>'Rotation failed']);

        $tool = $this->toolModel->findBySlug('pdf-rotate');
        if ($tool) $this->toolModel->incrementUsage($tool['id']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'rotated.pdf']);
    }

    public function lock() {
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);
        $password = trim($_POST['password'] ?? '');
        if (!$password) jsonResponse(['success'=>false,'message'=>'Password required hai']);

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_PDF);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        $outputName = 'locked_' . uniqid() . '.pdf';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;

        $cmd = "pdftk " . escapeshellarg($saved['path']) . " output " . escapeshellarg($outputPath) . 
               " owner_pw " . escapeshellarg($password) . " user_pw " . escapeshellarg($password) . " 2>&1";
        exec($cmd, $output, $returnCode);

        if (!file_exists($outputPath)) jsonResponse(['success'=>false,'message'=>'PDF lock failed']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'locked.pdf']);
    }

    public function unlock() {
        if (empty($_FILES['file'])) jsonResponse(['success'=>false,'message'=>'File required hai']);
        $password = trim($_POST['password'] ?? '');

        $validation = FileHelper::validateUpload($_FILES['file'], ALLOWED_PDF);
        if (!$validation['success']) jsonResponse(['success'=>false,'message'=>$validation['message']]);

        $saved = FileHelper::saveUploadedFile($_FILES['file'], UPLOAD_TEMP_DIR);
        $outputName = 'unlocked_' . uniqid() . '.pdf';
        $outputPath = UPLOAD_PROCESSED_DIR . $outputName;

        $cmd = "pdftk " . escapeshellarg($saved['path']) . " input_pw " . escapeshellarg($password) . 
               " output " . escapeshellarg($outputPath) . " 2>&1";
        exec($cmd, $output, $returnCode);

        if (!file_exists($outputPath)) jsonResponse(['success'=>false,'message'=>'PDF unlock failed. Password galat ho sakta hai.']);

        $downloadUrl = APP_URL . '/api/file/download?file=' . urlencode($outputName) . '&type=processed';
        jsonResponse(['success'=>true,'download_url'=>$downloadUrl,'filename'=>'unlocked.pdf']);
    }
}
