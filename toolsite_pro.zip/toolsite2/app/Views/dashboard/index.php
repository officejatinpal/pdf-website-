<div class="dashboard-page">
    <section class="dashboard-hero bg-dark-blue">
        <div class="container">
            <h1>Welcome, <?= htmlspecialchars($user['name']) ?>! 👋</h1>
            <p>Aapka personal dashboard</p>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="dashboard-stats">
                <div class="stat-card"><i class="fas fa-file"></i><div><strong><?= $totalFiles ?></strong><span>Total Files</span></div></div>
                <div class="stat-card"><i class="fas fa-tools"></i><div><strong><?= $totalTools ?></strong><span>Tools Used</span></div></div>
                <div class="stat-card"><i class="fas fa-star"></i><div><strong><?= count($favoriteTools) ?></strong><span>Favorites</span></div></div>
            </div>
            <div class="dashboard-grid">
                <div class="dashboard-main">
                    <h3>Recent Activity</h3>
                    <?php if (empty($recentUsage)): ?>
                    <div class="empty-state"><i class="fas fa-history"></i><p>Abhi koi activity nahi hai. Tools use karein!</p><a href="<?= APP_URL ?>/" class="btn btn-primary">Tools Dekhein</a></div>
                    <?php else: ?>
                    <div class="activity-list">
                        <?php foreach ($recentUsage as $usage): ?>
                        <div class="activity-item">
                            <div class="act-icon"><i class="fas <?= htmlspecialchars($usage['icon'] ?? 'fa-file') ?>"></i></div>
                            <div class="act-info">
                                <strong><?= htmlspecialchars($usage['tool_name']) ?></strong>
                                <span><?= date('d M Y, H:i', strtotime($usage['created_at'])) ?></span>
                            </div>
                            <span class="status-badge status-<?= $usage['status'] ?>"><?= ucfirst($usage['status']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="dashboard-sidebar">
                    <h3>Favorite Tools</h3>
                    <?php if (empty($favoriteTools)): ?>
                    <p>Koi favorite tool nahi hai abhi. Tools pe ⭐ click karein!</p>
                    <?php else: ?>
                    <ul class="fav-list">
                        <?php foreach ($favoriteTools as $fav): ?>
                        <li><a href="<?= APP_URL ?>/tools/<?= $fav['slug'] ?>"><i class="fas <?= $fav['icon'] ?>"></i> <?= htmlspecialchars($fav['name']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>
