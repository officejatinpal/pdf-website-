<section class="tool-hero bg-dark-blue"><div class="container"><h1>Favorite Tools</h1><p>Aapke pasandida tools</p></div></section>
<section class="section"><div class="container">
<?php if (empty($favorites)): ?>
<div class="empty-state"><i class="fas fa-star"></i><p>Koi favorite tool nahi hai. Tools par ⭐ click karein!</p><a href="<?= APP_URL ?>/" class="btn btn-primary">Tools Dekhein</a></div>
<?php else: ?>
<div class="tools-grid">
    <?php foreach ($favorites as $tool): ?>
    <a href="<?= APP_URL ?>/tools/<?= htmlspecialchars($tool['slug']) ?>" class="tool-card">
        <div class="tool-icon"><i class="fas <?= htmlspecialchars($tool['icon'] ?? 'fa-tools') ?>"></i></div>
        <div class="tool-info"><h3><?= htmlspecialchars($tool['name']) ?></h3><p><?= htmlspecialchars(substr($tool['description'],0,60)) ?>...</p></div>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>
</div></section>
