<section class="tool-hero bg-dark-blue"><div class="container"><h1>File History</h1><p>Aapke dwara use kiye gaye tools ka record</p></div></section>
<section class="section"><div class="container">
<?php if (empty($history)): ?>
<div class="empty-state"><i class="fas fa-history"></i><p>Abhi koi history nahi hai.</p><a href="<?= APP_URL ?>/" class="btn btn-primary">Tools Use Karein</a></div>
<?php else: ?>
<div class="activity-list">
    <?php foreach ($history as $item): ?>
    <div class="activity-item">
        <div class="act-icon"><i class="fas fa-tools"></i></div>
        <div class="act-info"><strong><?= htmlspecialchars($item['tool_name']) ?></strong><span><?= date('d M Y, H:i', strtotime($item['created_at'])) ?></span></div>
        <span class="status-badge status-<?= $item['status'] ?>"><?= ucfirst($item['status']) ?></span>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
</div></section>
