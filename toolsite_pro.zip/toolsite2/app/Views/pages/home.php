<!-- HERO SECTION -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Free Online <span class="gradient-text">PDF & Image Tools</span></h1>
            <p>Merge, Split, Compress, Convert PDF files. Resize, Compress, Edit Images. 100% Free, Secure & Fast!</p>
            <!-- Search Bar -->
            <div class="hero-search">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="heroSearch" placeholder="Tool dhundein... jaise 'PDF Merge', 'Compress Image'" autocomplete="off">
                    <button class="btn btn-primary">Search</button>
                </div>
                <div id="heroSearchResults" class="search-dropdown"></div>
            </div>
            <div class="hero-stats">
                <div class="stat"><strong>50+</strong><span>Tools</span></div>
                <div class="stat"><strong>1M+</strong><span>Files Processed</span></div>
                <div class="stat"><strong>100%</strong><span>Free</span></div>
                <div class="stat"><strong>1 Hour</strong><span>Auto Delete</span></div>
            </div>
        </div>
    </div>
    <div class="hero-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
    </div>
</section>

<!-- POPULAR TOOLS -->
<section class="section" id="popular-tools">
    <div class="container">
        <div class="section-header">
            <h2>Popular Tools</h2>
            <p>Sabse zyada use hone wale tools</p>
        </div>
        <div class="tools-grid">
            <?php foreach ($popularTools as $tool): ?>
            <a href="<?= APP_URL ?>/tools/<?= htmlspecialchars($tool['slug']) ?>" class="tool-card">
                <div class="tool-icon">
                    <i class="fas <?= htmlspecialchars($tool['icon'] ?? 'fa-file') ?>"></i>
                </div>
                <div class="tool-info">
                    <h3><?= htmlspecialchars($tool['name']) ?></h3>
                    <p><?= htmlspecialchars(substr($tool['description'], 0, 60)) ?>...</p>
                </div>
                <span class="tool-badge"><?= ucfirst($tool['category']) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- PDF TOOLS CATEGORY -->
<section class="section bg-light" id="pdf-tools">
    <div class="container">
        <div class="section-header">
            <h2><i class="fas fa-file-pdf text-red"></i> PDF Tools</h2>
            <p>PDF ke liye sab kuch - ek hi jagah</p>
        </div>
        <div class="category-tabs">
            <button class="tab-btn active" data-tab="pdf-management">Management</button>
            <button class="tab-btn" data-tab="pdf-conversion">Conversion</button>
            <button class="tab-btn" data-tab="pdf-security">Security</button>
            <button class="tab-btn" data-tab="pdf-editing">Editing</button>
        </div>
        <div class="tab-content active" id="pdf-management">
            <div class="tools-grid-small">
                <?php foreach ($pdfTools as $t): if ($t['sub_category'] === 'management'): ?>
                <a href="<?= APP_URL ?>/tools/<?= $t['slug'] ?>" class="tool-card-sm">
                    <i class="fas <?= htmlspecialchars($t['icon'] ?? 'fa-file') ?>"></i>
                    <span><?= htmlspecialchars($t['name']) ?></span>
                </a>
                <?php endif; endforeach; ?>
            </div>
        </div>
        <div class="tab-content" id="pdf-conversion">
            <div class="tools-grid-small">
                <?php foreach ($pdfTools as $t): if ($t['sub_category'] === 'conversion'): ?>
                <a href="<?= APP_URL ?>/tools/<?= $t['slug'] ?>" class="tool-card-sm">
                    <i class="fas <?= htmlspecialchars($t['icon'] ?? 'fa-file') ?>"></i>
                    <span><?= htmlspecialchars($t['name']) ?></span>
                </a>
                <?php endif; endforeach; ?>
            </div>
        </div>
        <div class="tab-content" id="pdf-security">
            <div class="tools-grid-small">
                <?php foreach ($pdfTools as $t): if ($t['sub_category'] === 'security'): ?>
                <a href="<?= APP_URL ?>/tools/<?= $t['slug'] ?>" class="tool-card-sm">
                    <i class="fas <?= htmlspecialchars($t['icon'] ?? 'fa-file') ?>"></i>
                    <span><?= htmlspecialchars($t['name']) ?></span>
                </a>
                <?php endif; endforeach; ?>
            </div>
        </div>
        <div class="tab-content" id="pdf-editing">
            <div class="tools-grid-small">
                <?php foreach ($pdfTools as $t): if ($t['sub_category'] === 'editing' || $t['sub_category'] === 'optimization'): ?>
                <a href="<?= APP_URL ?>/tools/<?= $t['slug'] ?>" class="tool-card-sm">
                    <i class="fas <?= htmlspecialchars($t['icon'] ?? 'fa-file') ?>"></i>
                    <span><?= htmlspecialchars($t['name']) ?></span>
                </a>
                <?php endif; endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- IMAGE TOOLS CATEGORY -->
<section class="section" id="image-tools">
    <div class="container">
        <div class="section-header">
            <h2><i class="fas fa-image text-blue"></i> Image Tools</h2>
            <p>Images ke liye powerful tools</p>
        </div>
        <div class="tools-grid">
            <?php foreach ($imageTools as $tool): ?>
            <a href="<?= APP_URL ?>/tools/<?= htmlspecialchars($tool['slug']) ?>" class="tool-card">
                <div class="tool-icon bg-blue">
                    <i class="fas <?= htmlspecialchars($tool['icon'] ?? 'fa-image') ?>"></i>
                </div>
                <div class="tool-info">
                    <h3><?= htmlspecialchars($tool['name']) ?></h3>
                    <p><?= htmlspecialchars(substr($tool['description'], 0, 60)) ?>...</p>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- FEATURES SECTION -->
<section class="section bg-dark-blue features-section">
    <div class="container">
        <div class="section-header light">
            <h2>Kyun Choose Karein Humein?</h2>
            <p>Features jo aapko kahin aur nahi milenge</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
                <h3>100% Secure</h3>
                <p>Aapki files HTTPS ke through process hoti hain. 1 ghante baad automatically delete.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-bolt"></i></div>
                <h3>Super Fast</h3>
                <p>High-performance servers par process hota hai. Seconds mein result milta hai.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-rupee-sign"></i></div>
                <h3>Bilkul Free</h3>
                <p>Sabhi basic tools completely free hain. Koi hidden charges nahi.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-mobile-alt"></i></div>
                <h3>Mobile Friendly</h3>
                <p>Mobile, tablet ya desktop - har device par perfectly kaam karta hai.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                <h3>Drag & Drop</h3>
                <p>Files ko simply drag karke drop karein. Koi complicated steps nahi.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-language"></i></div>
                <h3>Hindi Support</h3>
                <p>Hamaara interface Hindi mein bhi available hai. Apni bhasha mein use karein.</p>
            </div>
        </div>
    </div>
</section>

<!-- HOW TO USE -->
<section class="section" id="how-to-use">
    <div class="container">
        <div class="section-header">
            <h2>Kaise Use Karein?</h2>
            <p>3 simple steps mein kaam ho jaata hai</p>
        </div>
        <div class="steps-grid">
            <div class="step-card">
                <div class="step-num">1</div>
                <div class="step-icon"><i class="fas fa-upload"></i></div>
                <h3>File Upload Karein</h3>
                <p>Apni file choose karein ya drag & drop karein. Multiple files bhi select kar sakte hain.</p>
            </div>
            <div class="step-arrow"><i class="fas fa-arrow-right"></i></div>
            <div class="step-card">
                <div class="step-num">2</div>
                <div class="step-icon"><i class="fas fa-cog"></i></div>
                <h3>Settings Choose Karein</h3>
                <p>Apni zaroorat ke hisaab se options select karein. Jaise quality, pages, format etc.</p>
            </div>
            <div class="step-arrow"><i class="fas fa-arrow-right"></i></div>
            <div class="step-card">
                <div class="step-num">3</div>
                <div class="step-icon"><i class="fas fa-download"></i></div>
                <h3>Download Karein</h3>
                <p>Process complete hone ke baad apni file download karein. 1 click mein!</p>
            </div>
        </div>
    </div>
</section>

<!-- FAQ SECTION -->
<section class="section bg-light" id="faq">
    <div class="container">
        <div class="section-header">
            <h2>Aksar Pooche Jaane Wale Sawal</h2>
            <p>Frequently Asked Questions</p>
        </div>
        <!-- FAQ Schema Markup -->
        <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                <?php foreach ($faqs as $i => $faq): ?>
                {
                    "@type": "Question",
                    "name": "<?= htmlspecialchars($faq['question']) ?>",
                    "acceptedAnswer": {"@type": "Answer","text": "<?= htmlspecialchars($faq['answer']) ?>"}
                }<?= $i < count($faqs) - 1 ? ',' : '' ?>
                <?php endforeach; ?>
            ]
        }
        </script>
        <div class="faq-list">
            <?php foreach ($faqs as $i => $faq): ?>
            <div class="faq-item <?= $i === 0 ? 'active' : '' ?>">
                <button class="faq-question">
                    <span><?= htmlspecialchars($faq['question']) ?></span>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <div class="faq-answer">
                    <p><?= htmlspecialchars($faq['answer']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- BLOG SECTION -->
<?php if (!empty($blogs)): ?>
<section class="section" id="blog">
    <div class="container">
        <div class="section-header">
            <h2>Latest Blog Posts</h2>
            <p>Tips, Tutorials aur PDF/Image Tools ki jankari</p>
        </div>
        <div class="blog-grid">
            <?php foreach ($blogs as $blog): ?>
            <a href="<?= APP_URL ?>/blog/<?= htmlspecialchars($blog['slug']) ?>" class="blog-card">
                <?php if ($blog['featured_image']): ?>
                <div class="blog-img">
                    <img src="<?= htmlspecialchars($blog['featured_image']) ?>" alt="<?= htmlspecialchars($blog['title']) ?>" loading="lazy">
                </div>
                <?php endif; ?>
                <div class="blog-body">
                    <span class="blog-date"><?= date('d M Y', strtotime($blog['published_at'])) ?></span>
                    <h3><?= htmlspecialchars($blog['title']) ?></h3>
                    <p><?= htmlspecialchars(substr($blog['excerpt'], 0, 100)) ?>...</p>
                    <span class="read-more">Padhein <i class="fas fa-arrow-right"></i></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4">
            <a href="<?= APP_URL ?>/blog" class="btn btn-outline">Sab Blog Posts Dekhein</a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- REVIEWS SECTION -->
<?php if (!empty($reviews)): ?>
<section class="section bg-light" id="reviews">
    <div class="container">
        <div class="section-header">
            <h2>User Reviews</h2>
            <p>Hamara users kya sochte hain hamare baare mein</p>
        </div>
        <div class="reviews-slider" id="reviewsSlider">
            <?php foreach ($reviews as $review): ?>
            <div class="review-card">
                <div class="review-stars">
                    <?php for ($s = 1; $s <= 5; $s++): ?>
                    <i class="fas fa-star <?= $s <= $review['rating'] ? 'filled' : '' ?>"></i>
                    <?php endfor; ?>
                </div>
                <p class="review-text">"<?= htmlspecialchars($review['comment']) ?>"</p>
                <div class="reviewer">
                    <div class="reviewer-avatar"><?= strtoupper(substr($review['name'], 0, 1)) ?></div>
                    <div>
                        <strong><?= htmlspecialchars($review['name']) ?></strong>
                        <span><?= date('M Y', strtotime($review['created_at'])) ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
