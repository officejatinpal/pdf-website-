<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? APP_NAME) ?></title>
    <meta name="description" content="<?= htmlspecialchars($metaDesc ?? '') ?>">
    <meta name="robots" content="index, follow">
    <!-- Open Graph -->
    <meta property="og:title" content="<?= htmlspecialchars($pageTitle ?? APP_NAME) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($metaDesc ?? '') ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= APP_URL . htmlspecialchars($_SERVER['REQUEST_URI']) ?>">
    <!-- Canonical -->
    <link rel="canonical" href="<?= APP_URL . htmlspecialchars($_SERVER['REQUEST_URI']) ?>">
    <!-- CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
    <!-- PWA Manifest -->
    <link rel="manifest" href="<?= APP_URL ?>/manifest.json">
    <meta name="theme-color" content="#4F46E5">
    <?php if (isset($schemaMarkup)) echo $schemaMarkup; ?>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container nav-inner">
            <a href="<?= APP_URL ?>/" class="logo">
                <i class="fas fa-tools"></i>
                <span><?= APP_NAME ?></span>
            </a>
            <div class="nav-search">
                <input type="text" id="globalSearch" placeholder="Tools dhundein..." autocomplete="off">
                <div id="searchResults" class="search-dropdown"></div>
            </div>
            <ul class="nav-links">
                <li class="dropdown">
                    <a href="#">PDF Tools <i class="fas fa-chevron-down"></i></a>
                    <div class="dropdown-menu mega-menu">
                        <div class="mega-col">
                            <h4>Management</h4>
                            <a href="<?= APP_URL ?>/tools/pdf-merge">Merge PDF</a>
                            <a href="<?= APP_URL ?>/tools/pdf-split">Split PDF</a>
                            <a href="<?= APP_URL ?>/tools/pdf-compress">Compress PDF</a>
                            <a href="<?= APP_URL ?>/tools/pdf-rotate">Rotate PDF</a>
                        </div>
                        <div class="mega-col">
                            <h4>Conversion</h4>
                            <a href="<?= APP_URL ?>/tools/pdf-to-word">PDF to Word</a>
                            <a href="<?= APP_URL ?>/tools/word-to-pdf">Word to PDF</a>
                            <a href="<?= APP_URL ?>/tools/pdf-to-jpg">PDF to JPG</a>
                            <a href="<?= APP_URL ?>/tools/jpg-to-pdf">JPG to PDF</a>
                        </div>
                        <div class="mega-col">
                            <h4>Security</h4>
                            <a href="<?= APP_URL ?>/tools/lock-pdf">Lock PDF</a>
                            <a href="<?= APP_URL ?>/tools/unlock-pdf">Unlock PDF</a>
                            <a href="<?= APP_URL ?>/tools/add-watermark">Add Watermark</a>
                        </div>
                        <div class="mega-col">
                            <h4>Editing</h4>
                            <a href="<?= APP_URL ?>/tools/pdf-ocr">PDF OCR</a>
                            <a href="<?= APP_URL ?>/tools/pdf-add-numbers">Add Page Numbers</a>
                        </div>
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">Image Tools <i class="fas fa-chevron-down"></i></a>
                    <div class="dropdown-menu">
                        <a href="<?= APP_URL ?>/tools/resize-image">Resize Image</a>
                        <a href="<?= APP_URL ?>/tools/compress-image">Compress Image</a>
                        <a href="<?= APP_URL ?>/tools/crop-image">Crop Image</a>
                        <a href="<?= APP_URL ?>/tools/bg-remover">Background Remover</a>
                        <a href="<?= APP_URL ?>/tools/jpg-to-png">JPG to PNG</a>
                        <a href="<?= APP_URL ?>/tools/png-to-jpg">PNG to JPG</a>
                        <a href="<?= APP_URL ?>/tools/image-to-pdf">Image to PDF</a>
                    </div>
                </li>
                <li><a href="<?= APP_URL ?>/blog">Blog</a></li>
            </ul>
            <div class="nav-actions">
                <?php if (SessionHelper::isLoggedIn()): ?>
                    <div class="user-menu dropdown">
                        <button class="btn-avatar">
                            <?php $u = SessionHelper::user(); ?>
                            <img src="<?= htmlspecialchars($u['avatar'] ?? '') ?: 'https://ui-avatars.com/api/?name=' . urlencode($u['name']) . '&background=4F46E5&color=fff' ?>" alt="User">
                            <span><?= htmlspecialchars($u['name']) ?></span>
                        </button>
                        <div class="dropdown-menu">
                            <a href="<?= APP_URL ?>/dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                            <a href="<?= APP_URL ?>/dashboard/history"><i class="fas fa-history"></i> History</a>
                            <a href="<?= APP_URL ?>/dashboard/favorites"><i class="fas fa-star"></i> Favorites</a>
                            <hr>
                            <a href="<?= APP_URL ?>/auth/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= APP_URL ?>/login" class="btn btn-outline">Login</a>
                    <a href="<?= APP_URL ?>/register" class="btn btn-primary">Register</a>
                <?php endif; ?>
                <button id="darkModeToggle" class="btn-icon" title="Dark Mode">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
            <button class="hamburger" id="hamburger">
                <span></span><span></span><span></span>
            </button>
        </div>
    </nav>

    <!-- Flash Messages -->
    <?php $flash = SessionHelper::flash('message'); if ($flash): ?>
    <div class="alert alert-<?= SessionHelper::flash('type') ?? 'info' ?>"><?= htmlspecialchars($flash) ?></div>
    <?php endif; ?>

    <!-- Main Content -->
    <main>
        <?= $content ?>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="<?= APP_URL ?>/" class="logo">
                        <i class="fas fa-tools"></i>
                        <span><?= APP_NAME ?></span>
                    </a>
                    <p>Free online tools for PDF, Image and Document processing. Fast, secure and easy to use.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-col">
                    <h4>PDF Tools</h4>
                    <ul>
                        <li><a href="<?= APP_URL ?>/tools/pdf-merge">Merge PDF</a></li>
                        <li><a href="<?= APP_URL ?>/tools/pdf-split">Split PDF</a></li>
                        <li><a href="<?= APP_URL ?>/tools/pdf-compress">Compress PDF</a></li>
                        <li><a href="<?= APP_URL ?>/tools/pdf-to-word">PDF to Word</a></li>
                        <li><a href="<?= APP_URL ?>/tools/lock-pdf">Lock PDF</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Image Tools</h4>
                    <ul>
                        <li><a href="<?= APP_URL ?>/tools/resize-image">Resize Image</a></li>
                        <li><a href="<?= APP_URL ?>/tools/compress-image">Compress Image</a></li>
                        <li><a href="<?= APP_URL ?>/tools/bg-remover">Background Remover</a></li>
                        <li><a href="<?= APP_URL ?>/tools/jpg-to-png">JPG to PNG</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="<?= APP_URL ?>/about">About Us</a></li>
                        <li><a href="<?= APP_URL ?>/blog">Blog</a></li>
                        <li><a href="<?= APP_URL ?>/contact">Contact</a></li>
                        <li><a href="<?= APP_URL ?>/privacy-policy">Privacy Policy</a></li>
                        <li><a href="<?= APP_URL ?>/terms">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
                <p>Files automatically deleted after 1 hour | 100% Secure | HTTPS Encrypted</p>
            </div>
        </div>
    </footer>

    <script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body>
</html>
