<div class="tool-page">
    <section class="tool-hero" style="background:linear-gradient(135deg,#1D4ED8,#7C3AED)">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= APP_URL ?>/">Home</a>
                <i class="fas fa-chevron-right"></i>
                <a href="#">Image Tools</a>
                <i class="fas fa-chevron-right"></i>
                <span><?= htmlspecialchars($tool['name']) ?></span>
            </div>
            <div class="tool-header">
                <div class="tool-header-icon"><i class="fas <?= htmlspecialchars($tool['icon'] ?? 'fa-image') ?>"></i></div>
                <div>
                    <h1><?= htmlspecialchars($tool['name']) ?></h1>
                    <p><?= htmlspecialchars($tool['description']) ?></p>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="tool-layout">
                <div class="tool-main">
                    <div class="upload-area" id="uploadArea">
                        <div class="upload-inner" id="dropZone">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <h3>Image Upload Karein</h3>
                            <p>JPG, PNG, WEBP, GIF files supported hain</p>
                            <input type="file" id="fileInput" accept="image/*">
                            <button class="btn btn-primary" onclick="document.getElementById('fileInput').click()">
                                <i class="fas fa-folder-open"></i> Image Choose Karein
                            </button>
                            <p class="upload-note">Max size: 50MB | Files 1 ghante baad delete ho jaati hain</p>
                        </div>
                    </div>
                    <div id="fileList" class="file-list hidden"></div>
                    <div id="toolOptions" class="tool-options hidden">
                        <?php if ($toolAction === 'resize'): ?>
                        <div class="option-group">
                            <label>New Dimensions</label>
                            <div style="display:flex;gap:12px;align-items:center">
                                <input type="number" id="resizeWidth" class="form-input" placeholder="Width (px)" min="1" max="10000" style="flex:1">
                                <span>×</span>
                                <input type="number" id="resizeHeight" class="form-input" placeholder="Height (px)" min="1" max="10000" style="flex:1">
                            </div>
                            <label style="margin-top:10px;display:flex;align-items:center;gap:8px;font-weight:normal">
                                <input type="checkbox" id="maintainAspect" checked> Aspect ratio maintain karein
                            </label>
                        </div>
                        <?php elseif ($toolAction === 'compress'): ?>
                        <div class="option-group">
                            <label>Quality: <span id="qualityVal">80</span>%</label>
                            <input type="range" id="compressQuality" min="10" max="100" value="80" style="width:100%"
                                   oninput="document.getElementById('qualityVal').textContent=this.value">
                        </div>
                        <?php endif; ?>
                        <button class="btn btn-primary btn-lg btn-process" id="processBtn">
                            <i class="fas fa-cog"></i> Process Karein
                        </button>
                    </div>
                    <div id="progressArea" class="progress-area hidden">
                        <div class="progress-bar-wrap"><div class="progress-bar" id="progressBar"></div></div>
                        <p id="progressText">Processing...</p>
                    </div>
                    <div id="resultArea" class="result-area hidden">
                        <div class="result-success">
                            <i class="fas fa-check-circle"></i>
                            <h3>Image Ready Hai!</h3>
                            <div id="resultInfo"></div>
                            <a id="downloadBtn" class="btn btn-success btn-lg" href="#" download>
                                <i class="fas fa-download"></i> Download Karein
                            </a>
                            <button class="btn btn-outline" onclick="resetTool()">
                                <i class="fas fa-redo"></i> Dubara Try Karein
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tool-sidebar">
                    <div class="sidebar-card">
                        <h4>Related Tools</h4>
                        <ul class="related-tools">
                            <?php foreach (array_slice($relatedTools, 0, 8) as $rt): ?>
                            <?php if ($rt['slug'] !== $tool['slug']): ?>
                            <li><a href="<?= APP_URL ?>/tools/<?= htmlspecialchars($rt['slug']) ?>">
                                <i class="fas <?= htmlspecialchars($rt['icon'] ?? 'fa-image') ?>"></i>
                                <?= htmlspecialchars($rt['name']) ?>
                            </a></li>
                            <?php endif; endforeach; ?>
                        </ul>
                    </div>
                    <div class="sidebar-card security-card">
                        <h4><i class="fas fa-shield-alt"></i> 100% Secure</h4>
                        <ul>
                            <li><i class="fas fa-check"></i> HTTPS Encrypted</li>
                            <li><i class="fas fa-check"></i> 1 Ghante Baad Auto Delete</li>
                            <li><i class="fas fa-check"></i> No Data Sharing</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script>
const TOOL_ACTION = '<?= htmlspecialchars($toolAction) ?>';
const API_URL = '<?= APP_URL ?>/api/image/<?= htmlspecialchars($toolAction) ?>';
</script>
<script src="<?= APP_URL ?>/assets/js/tool.js"></script>
<script>
// Image-specific overrides
const origProcessFiles = processFiles;
processBtn?.addEventListener('click', async function(e) {
    e.stopImmediatePropagation();
    if (!selectedFiles.length) { showAlert('Pehle image select karein!', 'error'); return; }
    const formData = new FormData();
    formData.append('file', selectedFiles[0]);
    if (TOOL_ACTION === 'resize') {
        const w = document.getElementById('resizeWidth')?.value;
        const h = document.getElementById('resizeHeight')?.value;
        if (w) formData.append('width', w);
        if (h) formData.append('height', h);
        formData.append('maintain_aspect', document.getElementById('maintainAspect')?.checked ? '1' : '0');
    } else if (TOOL_ACTION === 'compress') {
        formData.append('quality', document.getElementById('compressQuality')?.value || 80);
    }
    toolOptions.classList.add('hidden');
    progressArea.classList.remove('hidden');
    processBtn.disabled = true;
    let prog = 0;
    const progInterval = setInterval(() => {
        prog = Math.min(prog + 20, 80);
        progressBar.style.width = prog + '%';
    }, 400);
    try {
        const res = await fetch(API_URL, { method:'POST', body: formData });
        const data = await res.json();
        clearInterval(progInterval);
        progressBar.style.width = '100%';
        setTimeout(() => {
            progressArea.classList.add('hidden');
            if (data.success) showResult(data);
            else { showAlert(data.message || 'Error', 'error'); toolOptions.classList.remove('hidden'); processBtn.disabled = false; }
        }, 500);
    } catch(e) {
        clearInterval(progInterval);
        progressArea.classList.add('hidden');
        showAlert('Network error', 'error');
        toolOptions.classList.remove('hidden'); processBtn.disabled = false;
    }
}, { once: false });
</script>
