<div class="tool-page">
    <!-- Tool Header -->
    <section class="tool-hero">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= APP_URL ?>/">Home</a>
                <i class="fas fa-chevron-right"></i>
                <a href="#">PDF Tools</a>
                <i class="fas fa-chevron-right"></i>
                <span><?= htmlspecialchars($tool['name']) ?></span>
            </div>
            <div class="tool-header">
                <div class="tool-header-icon">
                    <i class="fas <?= htmlspecialchars($tool['icon'] ?? 'fa-file-pdf') ?>"></i>
                </div>
                <div>
                    <h1><?= htmlspecialchars($tool['name']) ?></h1>
                    <p><?= htmlspecialchars($tool['description']) ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Tool Area -->
    <section class="section">
        <div class="container">
            <div class="tool-layout">
                <!-- Main Tool Area -->
                <div class="tool-main">
                    <div class="upload-area" id="uploadArea">
                        <div class="upload-inner" id="dropZone">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <h3>Files Upload Karein</h3>
                            <p>Files ko drag & drop karein ya click karke choose karein</p>
                            <input type="file" id="fileInput" 
                                   <?= in_array($toolAction, ['merge']) ? 'multiple' : '' ?>
                                   accept="<?= $toolAction === 'jpg-to-pdf' || $toolAction === 'word-to-pdf' ? '.jpg,.jpeg,.png,.docx,.doc' : '.pdf' ?>">
                            <button class="btn btn-primary" onclick="document.getElementById('fileInput').click()">
                                <i class="fas fa-folder-open"></i> Files Choose Karein
                            </button>
                            <p class="upload-note">Max size: 50MB | Files 1 ghante baad delete ho jaati hain</p>
                        </div>
                    </div>

                    <!-- File List -->
                    <div id="fileList" class="file-list hidden"></div>

                    <!-- Tool Specific Options -->
                    <div id="toolOptions" class="tool-options hidden">
                        <?php if ($toolAction === 'compress'): ?>
                        <div class="option-group">
                            <label>Compression Quality</label>
                            <div class="quality-options">
                                <label><input type="radio" name="quality" value="screen" checked> Low (Best Compression)</label>
                                <label><input type="radio" name="quality" value="ebook"> Medium (Recommended)</label>
                                <label><input type="radio" name="quality" value="printer"> High (Best Quality)</label>
                            </div>
                        </div>
                        <?php elseif ($toolAction === 'rotate'): ?>
                        <div class="option-group">
                            <label>Rotation Angle</label>
                            <div class="rotate-options">
                                <button class="rotate-btn" data-angle="90"><i class="fas fa-redo"></i> 90° Right</button>
                                <button class="rotate-btn" data-angle="180"><i class="fas fa-sync"></i> 180°</button>
                                <button class="rotate-btn" data-angle="270"><i class="fas fa-undo"></i> 90° Left</button>
                            </div>
                        </div>
                        <?php elseif ($toolAction === 'lock'): ?>
                        <div class="option-group">
                            <label>PDF Password Set Karein</label>
                            <input type="password" id="pdfPassword" class="form-input" placeholder="Password enter karein">
                            <input type="password" id="pdfPasswordConfirm" class="form-input" placeholder="Password dobara enter karein">
                        </div>
                        <?php elseif ($toolAction === 'unlock'): ?>
                        <div class="option-group">
                            <label>PDF Password Enter Karein</label>
                            <input type="password" id="pdfPassword" class="form-input" placeholder="PDF ka password enter karein">
                        </div>
                        <?php elseif ($toolAction === 'split'): ?>
                        <div class="option-group">
                            <label>Split Options</label>
                            <select id="splitType" class="form-input">
                                <option value="all">Sabhi Pages (Alag-Alag)</option>
                                <option value="range">Page Range (jaise: 1-3)</option>
                            </select>
                            <input type="text" id="splitPages" class="form-input hidden" placeholder="Pages enter karein jaise: 1-3, 5, 7-9">
                        </div>
                        <?php elseif ($toolAction === 'watermark'): ?>
                        <div class="option-group">
                            <label>Watermark Text</label>
                            <input type="text" id="watermarkText" class="form-input" placeholder="Watermark text enter karein">
                            <div class="watermark-opts">
                                <label>Opacity: <input type="range" id="watermarkOpacity" min="10" max="100" value="50"></label>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <button class="btn btn-primary btn-lg btn-process" id="processBtn">
                            <i class="fas fa-cog"></i> Process Karein
                        </button>
                    </div>

                    <!-- Progress Bar -->
                    <div id="progressArea" class="progress-area hidden">
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" id="progressBar"></div>
                        </div>
                        <p id="progressText">Processing...</p>
                    </div>

                    <!-- Result Area -->
                    <div id="resultArea" class="result-area hidden">
                        <div class="result-success">
                            <i class="fas fa-check-circle"></i>
                            <h3>Kaamyab! File Ready Hai</h3>
                            <div id="resultInfo"></div>
                            <a id="downloadBtn" class="btn btn-success btn-lg" href="#" download>
                                <i class="fas fa-download"></i> Download Karein
                            </a>
                            <button class="btn btn-outline" onclick="resetTool()">
                                <i class="fas fa-redo"></i> Dubara Try Karein
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="tool-sidebar">
                    <div class="sidebar-card">
                        <h4>Related Tools</h4>
                        <ul class="related-tools">
                            <?php foreach (array_slice($relatedTools, 0, 8) as $rt): ?>
                            <?php if ($rt['slug'] !== $tool['slug']): ?>
                            <li>
                                <a href="<?= APP_URL ?>/tools/<?= htmlspecialchars($rt['slug']) ?>">
                                    <i class="fas <?= htmlspecialchars($rt['icon'] ?? 'fa-file') ?>"></i>
                                    <?= htmlspecialchars($rt['name']) ?>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="sidebar-card security-card">
                        <h4><i class="fas fa-shield-alt"></i> 100% Secure</h4>
                        <ul>
                            <li><i class="fas fa-check"></i> HTTPS Encrypted</li>
                            <li><i class="fas fa-check"></i> 1 Ghante Baad Auto Delete</li>
                            <li><i class="fas fa-check"></i> No Data Sharing</li>
                            <li><i class="fas fa-check"></i> Malware Scan</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How To Use Section -->
    <section class="section bg-light">
        <div class="container">
            <h2><?= htmlspecialchars($tool['name']) ?> Kaise Karein?</h2>
            <div class="how-to-steps">
                <div class="step"><span>1</span> <p>Upar di gayi upload area mein apni file drag karein ya "Files Choose Karein" button click karein</p></div>
                <div class="step"><span>2</span> <p>Zaroorat ho toh settings choose karein (quality, password, etc.)</p></div>
                <div class="step"><span>3</span> <p>"Process Karein" button click karein aur result ready hone ka wait karein</p></div>
                <div class="step"><span>4</span> <p>"Download Karein" button click karke apni processed file save karein</p></div>
            </div>
        </div>
    </section>
</div>

<script>
const TOOL_ACTION = '<?= htmlspecialchars($toolAction) ?>';
const API_URL = '<?= APP_URL ?>/api/pdf/<?= htmlspecialchars($toolAction) ?>';
</script>
<script src="<?= APP_URL ?>/assets/js/tool.js"></script>
