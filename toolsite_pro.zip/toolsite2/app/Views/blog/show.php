<article class="blog-article">
    <section class="tool-hero">
        <div class="container" style="max-width:800px">
            <?php if ($post['category']): ?><span class="tool-badge" style="margin-bottom:12px;display:inline-block"><?= htmlspecialchars($post['category']) ?></span><?php endif; ?>
            <h1><?= htmlspecialchars($post['title']) ?></h1>
            <p style="opacity:.8"><?= date('d M Y', strtotime($post['published_at'])) ?> &bull; <?= $post['views'] ?> views</p>
        </div>
    </section>
    <?php if ($post['featured_image']): ?>
    <div style="max-width:800px;margin:0 auto;padding:0 20px">
        <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" style="width:100%;border-radius:12px;margin:20px 0">
    </div>
    <?php endif; ?>
    <section class="section" style="padding-top:30px">
        <div class="container" style="max-width:800px">
            <!-- Article Schema -->
            <script type="application/ld+json">
            {"@context":"https://schema.org","@type":"Article","headline":"<?= htmlspecialchars($post['title']) ?>","datePublished":"<?= $post['published_at'] ?>","description":"<?= htmlspecialchars($post['excerpt']) ?>"}
            </script>
            <div class="blog-content" style="line-height:1.9;font-size:1rem">
                <?= $post['content'] /* Content should be sanitized before inserting */ ?>
            </div>
        </div>
    </section>
</article>
<?php if (!empty($related)): ?>
<section class="section bg-light">
    <div class="container">
        <h2 style="margin-bottom:24px">Related Posts</h2>
        <div class="blog-grid">
            <?php foreach ($related as $r): ?>
            <a href="<?= APP_URL ?>/blog/<?= htmlspecialchars($r['slug']) ?>" class="blog-card">
                <?php if ($r['featured_image']): ?><div class="blog-img"><img src="<?= htmlspecialchars($r['featured_image']) ?>" alt="" loading="lazy"></div><?php endif; ?>
                <div class="blog-body"><h3><?= htmlspecialchars($r['title']) ?></h3><span class="read-more">Padhein <i class="fas fa-arrow-right"></i></span></div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
