<section class="tool-hero">
    <div class="container">
        <h1>Blog</h1>
        <p>PDF, Image tools ke tips, tutorials aur guides</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <?php if (empty($posts)): ?>
        <div class="empty-state"><i class="fas fa-blog"></i><p>Abhi koi blog post nahi hai.</p></div>
        <?php else: ?>
        <div class="blog-grid">
            <?php foreach ($posts as $post): ?>
            <a href="<?= APP_URL ?>/blog/<?= htmlspecialchars($post['slug']) ?>" class="blog-card">
                <?php if ($post['featured_image']): ?>
                <div class="blog-img"><img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" loading="lazy"></div>
                <?php endif; ?>
                <div class="blog-body">
                    <?php if ($post['category']): ?><span class="tool-badge"><?= htmlspecialchars($post['category']) ?></span><?php endif; ?>
                    <span class="blog-date"><?= date('d M Y', strtotime($post['published_at'])) ?></span>
                    <h3><?= htmlspecialchars($post['title']) ?></h3>
                    <p><?= htmlspecialchars(substr($post['excerpt'], 0, 120)) ?>...</p>
                    <span class="read-more">Padhein <i class="fas fa-arrow-right"></i></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
