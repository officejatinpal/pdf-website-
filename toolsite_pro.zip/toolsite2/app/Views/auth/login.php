<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <a href="<?= APP_URL ?>/" class="logo"><i class="fas fa-tools"></i> <?= APP_NAME ?></a>
            <h2>Login Karein</h2>
            <p>Apne account mein login karein</p>
        </div>
        <div id="alertMsg" class="alert hidden"></div>
        <form id="loginForm">
            <input type="hidden" name="csrf_token" value="<?= SessionHelper::csrf() ?>">
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" name="email" class="form-input" placeholder="aapka@email.com" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <div class="input-password">
                    <input type="password" name="password" class="form-input" placeholder="Password" required>
                    <button type="button" class="toggle-pass"><i class="fas fa-eye"></i></button>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <span>Login Karein</span> <i class="fas fa-sign-in-alt"></i>
            </button>
        </form>
        <div class="auth-divider"><span>Ya</span></div>
        <a href="<?= APP_URL ?>/auth/google" class="btn btn-google btn-block">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="18" alt="Google"> Google Se Login Karein
        </a>
        <div class="auth-footer">
            <p>Account nahi hai? <a href="<?= APP_URL ?>/register">Register Karein</a></p>
        </div>
    </div>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', async(e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Login ho raha hai...';
    const formData = new FormData(e.target);
    const res = await fetch('<?= APP_URL ?>/auth/login', {method:'POST', body: formData});
    const data = await res.json();
    const alert = document.getElementById('alertMsg');
    alert.className = 'alert ' + (data.success ? 'alert-success' : 'alert-error');
    alert.textContent = data.message || (data.success ? 'Login successful!' : 'Error');
    alert.classList.remove('hidden');
    if (data.success) window.location.href = data.redirect;
    else { btn.disabled = false; btn.innerHTML = '<span>Login Karein</span> <i class="fas fa-sign-in-alt"></i>'; }
});
document.querySelector('.toggle-pass')?.addEventListener('click', function() {
    const inp = this.previousElementSibling;
    inp.type = inp.type === 'password' ? 'text' : 'password';
    this.querySelector('i').classList.toggle('fa-eye-slash');
});
</script>
</body>
</html>
