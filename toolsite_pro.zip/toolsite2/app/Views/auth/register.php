<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <a href="<?= APP_URL ?>/" class="logo"><i class="fas fa-tools"></i> <?= APP_NAME ?></a>
            <h2>Free Account Banayein</h2>
            <p>Register karke saari features access karein</p>
        </div>
        <div id="alertMsg" class="alert hidden"></div>
        <form id="registerForm">
            <input type="hidden" name="csrf_token" value="<?= SessionHelper::csrf() ?>">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Full Name</label>
                <input type="text" name="name" class="form-input" placeholder="Aapka poora naam" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" name="email" class="form-input" placeholder="aapka@email.com" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-input" placeholder="Kam se kam 8 characters" required minlength="8">
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <span>Free Account Banayein</span> <i class="fas fa-user-plus"></i>
            </button>
        </form>
        <div class="auth-divider"><span>Ya</span></div>
        <a href="<?= APP_URL ?>/auth/google" class="btn btn-google btn-block">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="18" alt="Google"> Google Se Register Karein
        </a>
        <div class="auth-footer">
            <p>Pehle se account hai? <a href="<?= APP_URL ?>/login">Login Karein</a></p>
            <p class="text-small">Register karke aap hamare <a href="/terms">Terms</a> aur <a href="/privacy-policy">Privacy Policy</a> se agree karte hain.</p>
        </div>
    </div>
</div>
<script>
document.getElementById('registerForm').addEventListener('submit', async(e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
    const formData = new FormData(e.target);
    const res = await fetch('<?= APP_URL ?>/auth/register', {method:'POST', body: formData});
    const data = await res.json();
    const alert = document.getElementById('alertMsg');
    alert.className = 'alert ' + (data.success ? 'alert-success' : 'alert-error');
    alert.textContent = data.message || '';
    alert.classList.remove('hidden');
    if (data.success) window.location.href = data.redirect;
    else { btn.disabled = false; btn.innerHTML = '<span>Free Account Banayein</span> <i class="fas fa-user-plus"></i>'; }
});
</script>
</body>
</html>
