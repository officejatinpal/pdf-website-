<?php
class FileHelper {

    public static function generateUniqueName($originalName) {
        $ext = pathinfo($originalName, PATHINFO_EXTENSION);
        return uniqid('file_', true) . '.' . strtolower($ext);
    }

    public static function sanitizeFileName($name) {
        $name = preg_replace('/[^a-zA-Z0-9._-]/', '_', $name);
        return substr($name, 0, 200);
    }

    public static function getFileType($mimeType) {
        if (in_array($mimeType, ALLOWED_PDF)) return 'pdf';
        if (in_array($mimeType, ALLOWED_IMAGE)) return 'image';
        if (in_array($mimeType, ALLOWED_DOCUMENT)) return 'document';
        return 'other';
    }

    public static function formatSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }

    public static function validateUpload($file, $allowedMimes = null) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'File upload error: ' . $file['error']];
        }
        if ($file['size'] > UPLOAD_MAX_SIZE) {
            return ['success' => false, 'message' => 'File too large. Max: ' . self::formatSize(UPLOAD_MAX_SIZE)];
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        if ($allowedMimes && !in_array($mimeType, $allowedMimes)) {
            return ['success' => false, 'message' => 'Invalid file type: ' . $mimeType];
        }
        return ['success' => true, 'mime_type' => $mimeType];
    }

    public static function saveUploadedFile($file, $dir = null) {
        $dir = $dir ?? UPLOAD_TEMP_DIR;
        $uniqueName = self::generateUniqueName($file['name']);
        $destPath = $dir . $uniqueName;
        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            return false;
        }
        return ['stored_name' => $uniqueName, 'path' => $destPath];
    }

    public static function deleteOldFiles() {
        $db = Database::getInstance();
        $expiredFiles = $db->fetchAll(
            "SELECT * FROM file_uploads WHERE expires_at <= NOW() AND is_deleted = 0"
        );
        foreach ($expiredFiles as $file) {
            if (file_exists($file['file_path'])) {
                unlink($file['file_path']);
            }
            $db->update('file_uploads', ['is_deleted' => 1], 'id = ?', [$file['id']]);
        }
        return count($expiredFiles);
    }

    public static function createZip($files, $outputPath) {
        $zip = new ZipArchive();
        if ($zip->open($outputPath, ZipArchive::CREATE) !== true) {
            return false;
        }
        foreach ($files as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();
        return true;
    }
}
