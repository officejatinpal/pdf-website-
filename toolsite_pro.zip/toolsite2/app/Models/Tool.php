<?php
class Tool {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAll($category = null) {
        if ($category) {
            return $this->db->fetchAll(
                "SELECT * FROM tools WHERE category = ? AND is_active = 1 ORDER BY sort_order",
                [$category]
            );
        }
        return $this->db->fetchAll("SELECT * FROM tools WHERE is_active = 1 ORDER BY category, sort_order");
    }

    public function getPopular($limit = 8) {
        return $this->db->fetchAll(
            "SELECT * FROM tools WHERE is_active = 1 ORDER BY usage_count DESC LIMIT ?",
            [$limit]
        );
    }

    public function findBySlug($slug) {
        return $this->db->fetch("SELECT * FROM tools WHERE slug = ? AND is_active = 1", [$slug]);
    }

    public function incrementUsage($toolId) {
        $this->db->query("UPDATE tools SET usage_count = usage_count + 1 WHERE id = ?", [$toolId]);
    }

    public function getByCategory() {
        $tools = $this->getAll();
        $grouped = [];
        foreach ($tools as $tool) {
            $grouped[$tool['category']][] = $tool;
        }
        return $grouped;
    }
}
