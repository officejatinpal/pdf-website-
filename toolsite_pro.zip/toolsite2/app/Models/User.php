<?php
class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findById($id) {
        return $this->db->fetch("SELECT * FROM users WHERE id = ? AND is_active = 1", [$id]);
    }

    public function findByEmail($email) {
        return $this->db->fetch("SELECT * FROM users WHERE email = ?", [$email]);
    }

    public function findByGoogleId($googleId) {
        return $this->db->fetch("SELECT * FROM users WHERE google_id = ?", [$googleId]);
    }

    public function create($data) {
        return $this->db->insert('users', $data);
    }

    public function update($id, $data) {
        return $this->db->update('users', $data, 'id = ?', [$id]);
    }

    public function updateLastLogin($id) {
        return $this->db->update('users', ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
    }

    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    public function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
}
