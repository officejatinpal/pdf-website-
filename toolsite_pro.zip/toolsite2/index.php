<?php
// =========================================
// ToolSite Pro - Front Controller (index.php)
// Entry point for all requests
// =========================================

// Load Configuration
require_once __DIR__ . '/config/database.php';

// Autoload Classes
spl_autoload_register(function($class) {
    $paths = [
        __DIR__ . '/app/Controllers/' . $class . '.php',
        __DIR__ . '/app/Models/' . $class . '.php',
        __DIR__ . '/app/Helpers/' . $class . '.php',
        __DIR__ . '/app/Middleware/' . $class . '.php',
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) { require_once $path; return; }
    }
});

// Start Session
SessionHelper::start();

// Get Request URI
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// Remove base path if running in subdirectory
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
if ($basePath && strpos($requestUri, $basePath) === 0) {
    $requestUri = substr($requestUri, strlen($basePath));
}
$requestUri = '/' . ltrim($requestUri, '/');
if (empty($requestUri)) $requestUri = '/';

// Helper Functions
function redirect($url) {
    header('Location: ' . APP_URL . $url);
    exit;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data);
    exit;
}

// Load Routes
$routes = require_once __DIR__ . '/config/app.php';

// Simple Router
$matched = false;
foreach ($routes as $pattern => $handler) {
    // Convert route params {slug} to regex
    $regex = preg_replace('/\{[a-z]+\}/', '([^/]+)', $pattern);
    $regex = '#^' . $regex . '$#';
    
    if (preg_match($regex, $requestUri, $matches)) {
        array_shift($matches); // remove full match
        [$controllerName, $methodName] = $handler;
        
        if (class_exists($controllerName)) {
            $controller = new $controllerName();
            if (method_exists($controller, $methodName)) {
                call_user_func_array([$controller, $methodName], $matches);
                $matched = true;
                break;
            }
        }
    }
}

// Search API (inline)
if (!$matched && $requestUri === '/api/search') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) >= 2) {
        $db = Database::getInstance();
        $tools = $db->fetchAll(
            "SELECT name, slug, icon, description FROM tools WHERE is_active = 1 
             AND (name LIKE ? OR description LIKE ?) LIMIT 8",
            ["%$q%", "%$q%"]
        );
        jsonResponse(['tools' => $tools]);
    }
    jsonResponse(['tools' => []]);
    $matched = true;
}

// 404
if (!$matched) {
    http_response_code(404);
    echo '<!DOCTYPE html><html><head><title>404 - Page Not Found</title>
    <link rel="stylesheet" href="' . APP_URL . '/assets/css/style.css">
    </head><body>
    <div style="text-align:center;padding:100px 20px;">
    <h1 style="font-size:5rem;color:#4F46E5;">404</h1>
    <h2>Page Not Found</h2>
    <p>Yeh page exist nahi karta.</p>
    <a href="' . APP_URL . '/" class="btn btn-primary" style="margin-top:20px;display:inline-flex;">Home Par Jaayein</a>
    </div></body></html>';
}

// Cleanup cron - run occasionally
if (mt_rand(1, 100) === 1) {
    register_shutdown_function(function() {
        try { FileHelper::deleteOldFiles(); } catch(Exception $e) {}
    });
}
