# 🛠️ ToolSite Pro - Complete PDF & Image Tools Website

**PHP + MySQL based free online tools website**  
PDF Merge, Compress, Convert, Image Resize, Background Remover aur 50+ tools!

---

## 📁 Project Structure (File Kya Hai Kisliye)

```
toolsite2/
│
├── index.php                    ← ENTRY POINT - Sabhi requests yahan aati hain (Front Controller)
├── .htaccess                    ← Apache URL rewriting + security headers + caching
├── manifest.json                ← PWA manifest (Install as App feature)
├── cron_cleanup.php             ← Files cleanup cron job (har 1 ghante mein chalega)
│
├── config/
│   ├── database.php             ← DB credentials, App settings, Upload limits, API keys
│   └── app.php                  ← All URL routes defined here (URL → Controller mapping)
│
├── database/
│   └── migrations/
│       └── 001_create_tables.sql  ← PEHLE YAHI CHALAO - Saare tables + seed data
│
├── app/
│   ├── Controllers/             ← Request handle karte hain, View render karte hain
│   │   ├── HomeController.php       ← Homepage (/, hero, popular tools, FAQ, reviews)
│   │   ├── AuthController.php       ← Login, Register, Google OAuth, Logout
│   │   ├── PdfController.php        ← PDF tool pages render karta hai
│   │   ├── ImageController.php      ← Image tool pages render karta hai
│   │   ├── DashboardController.php  ← User dashboard (history, favorites)
│   │   ├── BlogController.php       ← Blog list aur individual post
│   │   ├── PageController.php       ← Privacy, Terms, About, Contact pages
│   │   ├── ApiPdfController.php     ← PDF processing API (merge, split, compress, etc.)
│   │   ├── ApiImageController.php   ← Image processing API (resize, compress, bg-remove)
│   │   └── ApiFileController.php    ← File download aur delete API
│   │
│   ├── Models/                  ← Database ke saath baat karte hain
│   │   ├── Database.php             ← PDO database connection (Singleton pattern)
│   │   ├── User.php                 ← User CRUD operations
│   │   └── Tool.php                 ← Tools fetch, popular tools, usage count
│   │
│   ├── Helpers/                 ← Reusable utility functions
│   │   ├── FileHelper.php           ← File upload, validate, save, delete, zip creation
│   │   └── SessionHelper.php        ← Session management, login/logout, CSRF protection
│   │
│   ├── Middleware/              ← (Future use: Rate limiting, Auth check)
│   │
│   └── Views/                   ← HTML templates (PHP embedded)
│       ├── layouts/
│       │   ├── main.php             ← MAIN LAYOUT - Navbar + Footer (sabhi pages use karte hain)
│       │   └── auth.php             ← Auth layout (login/register ke liye)
│       │
│       ├── pages/
│       │   └── home.php             ← Homepage content (hero, tools, FAQ, blog, reviews)
│       │
│       ├── tools/
│       │   ├── pdf-tool.php         ← PDF tool page template (sab PDF tools use karte hain)
│       │   └── image-tool.php       ← Image tool page template
│       │
│       ├── auth/
│       │   ├── login.php            ← Login form page
│       │   └── register.php         ← Register form page
│       │
│       ├── dashboard/
│       │   ├── index.php            ← Dashboard home (stats, recent activity, favorites)
│       │   ├── history.php          ← Tool usage history
│       │   └── favorites.php        ← Saved favorite tools
│       │
│       └── blog/
│           ├── index.php            ← Blog listing page
│           └── show.php             ← Single blog post page
│
├── assets/
│   ├── css/
│   │   └── style.css            ← MAIN CSS - Dark mode, responsive, all components
│   ├── js/
│   │   ├── app.js               ← Main JS (search, tabs, FAQ, dark mode, hamburger)
│   │   └── tool.js              ← Tool page JS (drag-drop, upload, progress, download)
│   └── images/                  ← Logo, icons, OG image yahan rakhein
│
└── uploads/
    ├── temp/                    ← Uploaded files temporarily store hoti hain yahan
    └── processed/               ← Processed/output files yahan store hoti hain
```

---

## 🖥️ Local Setup (XAMPP / WAMP / MAMP)

### Prerequisites
- PHP 8.1+
- MySQL 5.7+
- Apache (mod_rewrite enabled)
- Ghostscript (PDF tools ke liye)
- pdftk (PDF tools ke liye)
- GD Library (Image tools ke liye)

### Step 1: Project Copy Karein
```bash
# XAMPP users
cp -r toolsite2/ C:/xampp/htdocs/toolsite2

# WAMP users
cp -r toolsite2/ C:/wamp64/www/toolsite2

# Linux/Mac XAMPP
cp -r toolsite2/ /opt/lampp/htdocs/toolsite2
```

### Step 2: Database Setup
```
1. XAMPP/WAMP start karein
2. Browser mein kholo: http://localhost/phpmyadmin
3. "SQL" tab mein jaao
4. database/migrations/001_create_tables.sql ka content paste karein
5. "Go" button click karein
6. Database 'toolsite_db' create ho jaayega with all tables + seed data
```

### Step 3: Configuration
```php
// config/database.php file edit karein:
define('DB_HOST', 'localhost');
define('DB_NAME', 'toolsite_db');
define('DB_USER', 'root');        // apna DB username
define('DB_PASS', '');            // apna DB password
define('APP_URL', 'http://localhost/toolsite2');  // ← IMPORTANT: apna URL
```

### Step 4: Permissions (Linux/Mac)
```bash
chmod -R 755 toolsite2/
chmod -R 777 toolsite2/uploads/
```

### Step 5: Tool Dependencies Install Karein
```bash
# Ubuntu/Debian
sudo apt-get install ghostscript pdftk

# Mac (Homebrew)
brew install ghostscript pdftk-java

# Windows (XAMPP)
# Ghostscript: https://www.ghostscript.com/download/gsdnld.html
# pdftk: https://www.pdflabs.com/tools/pdftk-the-pdf-toolkit/
```

### Step 6: Test
```
Browser kholo: http://localhost/toolsite2
```

---

## 🌐 Live Server Deployment (cPanel / VPS)

### Option A: cPanel Hosting

**Step 1: Files Upload Karein**
```
1. cPanel File Manager kholo
2. public_html/ mein jaao
3. toolsite2/ folder upload karein (ya domain root mein directly)
4. Ya FTP use karein (FileZilla recommended)
```

**Step 2: Database Create Karein**
```
1. cPanel → MySQL Databases
2. New database create karein: yourusername_toolsite
3. New user create karein: yourusername_tooluser
4. Password set karein (strong password)
5. User ko database pe "All Privileges" dein
6. phpMyAdmin mein jaao → SQL tab → 001_create_tables.sql run karein
```

**Step 3: config/database.php Update Karein**
```php
define('APP_URL', 'https://yourdomain.com');  // https with domain
define('DB_HOST', 'localhost');
define('DB_NAME', 'yourusername_toolsite');
define('DB_USER', 'yourusername_tooluser');
define('DB_PASS', 'yourStrongPassword');
define('APP_DEBUG', false);  // ← Production mein false karo
define('APP_ENV', 'production');
```

**Step 4: HTTPS Force Karein**
```
.htaccess mein yeh lines uncomment karein:
# RewriteCond %{HTTPS} off
# RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

**Step 5: Folder Permissions**
```
uploads/temp/     → 755
uploads/processed/ → 755
config/           → 644
```

**Step 6: Cron Job Setup (Auto File Cleanup)**
```
cPanel → Cron Jobs → Add New Cron Job
Frequency: Every Hour (0 * * * *)
Command: php /home/yourusername/public_html/cron_cleanup.php
```

### Option B: VPS (Ubuntu/Debian)

```bash
# 1. Apache + PHP + MySQL install
sudo apt update
sudo apt install apache2 php8.1 php8.1-mysql php8.1-gd php8.1-zip php8.1-curl libapache2-mod-php8.1
sudo apt install mysql-server ghostscript pdftk

# 2. Files upload
sudo mkdir /var/www/html/toolsite2
sudo cp -r toolsite2/* /var/www/html/toolsite2/
sudo chown -R www-data:www-data /var/www/html/toolsite2
sudo chmod -R 755 /var/www/html/toolsite2
sudo chmod -R 777 /var/www/html/toolsite2/uploads

# 3. Apache mod_rewrite enable
sudo a2enmod rewrite
sudo systemctl restart apache2

# 4. Apache virtual host
sudo nano /etc/apache2/sites-available/toolsite.conf
```
```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    DocumentRoot /var/www/html/toolsite2
    <Directory /var/www/html/toolsite2>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```
```bash
sudo a2ensite toolsite.conf
sudo systemctl reload apache2

# 5. SSL (Let's Encrypt - Free HTTPS)
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d yourdomain.com

# 6. MySQL database
sudo mysql -u root -p
CREATE DATABASE toolsite_db;
CREATE USER 'tooluser'@'localhost' IDENTIFIED BY 'StrongPass123!';
GRANT ALL ON toolsite_db.* TO 'tooluser'@'localhost';
EXIT;
mysql -u tooluser -p toolsite_db < /var/www/html/toolsite2/database/migrations/001_create_tables.sql

# 7. Cron job
crontab -e
# Add: 0 * * * * php /var/www/html/toolsite2/cron_cleanup.php >> /var/log/toolsite_cleanup.log 2>&1
```

---

## 🔧 Server Requirements Summary

| Requirement | Local (XAMPP) | Live Server |
|---|---|---|
| PHP Version | 8.0+ | 8.1+ recommended |
| MySQL | 5.7+ | 5.7+ / MariaDB 10.3+ |
| Apache | 2.4+ | 2.4+ |
| mod_rewrite | Enable | Enable |
| GD Extension | Enable | Enable |
| Ghostscript | Install separately | `apt install ghostscript` |
| pdftk | Install separately | `apt install pdftk` |
| Upload Limit | 50MB (php.ini) | 50MB (php.ini) |
| Memory Limit | 256MB | 256MB |
| Max Execution | 120 seconds | 120 seconds |

---

## 🔌 Optional API Integrations

### 1. Background Remover (remove.bg)
```php
// config/database.php mein add karein:
define('REMOVEBG_API_KEY', 'your_api_key_here');
// Free plan: 50 credits/month | https://www.remove.bg/api
```

### 2. Google OAuth Login
```php
// config/database.php mein:
define('GOOGLE_CLIENT_ID', 'your_client_id');
define('GOOGLE_CLIENT_SECRET', 'your_secret');
// Google Cloud Console: https://console.cloud.google.com
```

---

## 📦 Admin Panel Access

Admin panel future mein add karna ho toh:
1. `admin/` folder mein controllers rakho
2. Users table mein `role = 'admin'` set karo
3. DashboardController mein role check add karo

---

## 🚀 Tech Stack

- **Backend:** PHP 8.1 (MVC Pattern, No Framework)
- **Database:** MySQL 8.0 (PDO)
- **Frontend:** Vanilla JS + CSS3 (No jQuery dependency)
- **PDF Processing:** Ghostscript + pdftk
- **Image Processing:** PHP GD Library
- **Icons:** Font Awesome 6.5
- **Fonts:** Google Fonts (Inter)
- **PWA:** Web App Manifest

---

## 🔒 Security Features Implemented

- CSRF Protection (all POST forms)
- SQL Injection Prevention (PDO prepared statements)
- XSS Prevention (htmlspecialchars)
- File type validation (MIME type check)
- Secure filename generation (uniqid)
- Auto file deletion (1 hour)
- .htaccess directory protection
- Security headers (X-Frame-Options, XSS-Protection, etc.)
- Session security (httponly, secure cookies)

---

## ⚠️ Known Limitations & Next Steps

1. **PDF Conversion (PDF to Word/Excel):** LibreOffice install karna hoga VPS par
2. **OCR:** Tesseract OCR install karna hoga
3. **Background Remover:** remove.bg API key chahiye
4. **Google Login:** Google OAuth credentials chahiye
5. **Email Verification:** SMTP configure karna hoga

### LibreOffice for Document Conversion
```bash
sudo apt install libreoffice
# Then in ApiPdfController, use:
# exec("libreoffice --headless --convert-to docx --outdir /path/ input.pdf");
```

---

Made with ❤️ | PHP + MySQL | 100% Free & Open Source
