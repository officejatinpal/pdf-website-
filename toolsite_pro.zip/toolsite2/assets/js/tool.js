/* =========================================
   ToolSite Pro - Tool Page JavaScript
   ========================================= */

// Variables
let selectedFiles = [];
let selectedAngle = 90;

const uploadArea    = document.getElementById('uploadArea');
const dropZone      = document.getElementById('dropZone');
const fileInput     = document.getElementById('fileInput');
const fileList      = document.getElementById('fileList');
const toolOptions   = document.getElementById('toolOptions');
const processBtn    = document.getElementById('processBtn');
const progressArea  = document.getElementById('progressArea');
const progressBar   = document.getElementById('progressBar');
const progressText  = document.getElementById('progressText');
const resultArea    = document.getElementById('resultArea');
const downloadBtn   = document.getElementById('downloadBtn');
const resultInfo    = document.getElementById('resultInfo');

// ---- DRAG & DROP ----
['dragenter','dragover'].forEach(e => {
    dropZone?.addEventListener(e, (ev) => {
        ev.preventDefault();
        uploadArea.classList.add('drag-over');
    });
});
['dragleave','drop'].forEach(e => {
    dropZone?.addEventListener(e, (ev) => {
        ev.preventDefault();
        uploadArea.classList.remove('drag-over');
    });
});
dropZone?.addEventListener('drop', (e) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
});
fileInput?.addEventListener('change', () => {
    handleFiles(Array.from(fileInput.files));
});

function handleFiles(files) {
    if (TOOL_ACTION !== 'merge') {
        selectedFiles = [files[0]]; // single file only
    } else {
        selectedFiles = [...selectedFiles, ...files];
    }
    renderFileList();
}

function renderFileList() {
    if (!selectedFiles.length) {
        fileList.classList.add('hidden');
        toolOptions.classList.add('hidden');
        return;
    }
    fileList.classList.remove('hidden');
    toolOptions.classList.remove('hidden');
    fileList.innerHTML = selectedFiles.map((f, i) => `
        <div class="file-item" data-index="${i}">
            <i class="fas ${getFileIcon(f.name)} file-item-icon"></i>
            <div class="file-item-info">
                <span>${escHtml(f.name)}</span>
                <small>${formatSize(f.size)}</small>
            </div>
            <button class="file-item-remove" onclick="removeFile(${i})" title="Remove">
                <i class="fas fa-times"></i>
            </button>
        </div>`).join('');
}

function removeFile(index) {
    selectedFiles.splice(index, 1);
    renderFileList();
}

function getFileIcon(name) {
    const ext = name.split('.').pop().toLowerCase();
    const map = { pdf: 'fa-file-pdf', jpg: 'fa-file-image', jpeg: 'fa-file-image', png: 'fa-file-image',
        docx: 'fa-file-word', doc: 'fa-file-word', xlsx: 'fa-file-excel', xls: 'fa-file-excel',
        pptx: 'fa-file-powerpoint', ppt: 'fa-file-powerpoint' };
    return map[ext] || 'fa-file';
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/1048576).toFixed(1) + ' MB';
}

function escHtml(str) {
    return str.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ---- ROTATE BUTTONS ----
document.querySelectorAll('.rotate-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.rotate-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedAngle = parseInt(btn.dataset.angle);
    });
});

// ---- SPLIT TYPE ----
document.getElementById('splitType')?.addEventListener('change', function() {
    const pagesInput = document.getElementById('splitPages');
    if (this.value === 'range') pagesInput?.classList.remove('hidden');
    else pagesInput?.classList.add('hidden');
});

// ---- PROCESS BUTTON ----
processBtn?.addEventListener('click', processFiles);

async function processFiles() {
    if (!selectedFiles.length) {
        showAlert('Pehle file select karein!', 'error');
        return;
    }

    // Build FormData
    const formData = new FormData();

    if (TOOL_ACTION === 'merge') {
        selectedFiles.forEach(f => formData.append('files[]', f));
    } else {
        formData.append('file', selectedFiles[0]);
    }

    // Append options based on tool
    if (TOOL_ACTION === 'compress') {
        const quality = document.querySelector('input[name="quality"]:checked')?.value || 'screen';
        formData.append('quality', quality);
    } else if (TOOL_ACTION === 'rotate') {
        formData.append('angle', selectedAngle);
    } else if (TOOL_ACTION === 'lock') {
        const pass = document.getElementById('pdfPassword')?.value;
        const passConfirm = document.getElementById('pdfPasswordConfirm')?.value;
        if (!pass) { showAlert('Password enter karein!', 'error'); return; }
        if (pass !== passConfirm) { showAlert('Passwords match nahi karte!', 'error'); return; }
        formData.append('password', pass);
    } else if (TOOL_ACTION === 'unlock') {
        const pass = document.getElementById('pdfPassword')?.value;
        if (!pass) { showAlert('Password enter karein!', 'error'); return; }
        formData.append('password', pass);
    } else if (TOOL_ACTION === 'split') {
        formData.append('split_type', document.getElementById('splitType')?.value || 'all');
        const pages = document.getElementById('splitPages')?.value;
        if (pages) formData.append('pages', pages);
    } else if (TOOL_ACTION === 'watermark') {
        const text = document.getElementById('watermarkText')?.value;
        if (!text) { showAlert('Watermark text enter karein!', 'error'); return; }
        formData.append('watermark_text', text);
        formData.append('opacity', document.getElementById('watermarkOpacity')?.value || 50);
    }

    // Show progress
    toolOptions.classList.add('hidden');
    progressArea.classList.remove('hidden');
    resultArea.classList.add('hidden');
    processBtn.disabled = true;

    // Simulate progress
    let prog = 0;
    const progInterval = setInterval(() => {
        prog = Math.min(prog + Math.random() * 15, 85);
        progressBar.style.width = prog + '%';
        progressText.textContent = getProgressText(prog);
    }, 500);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: formData });
        const data = await res.json();

        clearInterval(progInterval);
        progressBar.style.width = '100%';
        progressText.textContent = 'Complete!';

        setTimeout(() => {
            progressArea.classList.add('hidden');
            if (data.success) {
                showResult(data);
            } else {
                showAlert(data.message || 'Processing failed', 'error');
                toolOptions.classList.remove('hidden');
                processBtn.disabled = false;
            }
        }, 600);

    } catch(err) {
        clearInterval(progInterval);
        progressArea.classList.add('hidden');
        showAlert('Network error. Please try again.', 'error');
        toolOptions.classList.remove('hidden');
        processBtn.disabled = false;
    }
}

function getProgressText(prog) {
    if (prog < 20) return 'File upload ho rahi hai...';
    if (prog < 50) return 'Processing chal rahi hai...';
    if (prog < 80) return 'Almost done...';
    return 'Final touches...';
}

function showResult(data) {
    resultArea.classList.remove('hidden');
    downloadBtn.href = data.download_url;
    downloadBtn.download = data.filename || 'processed_file';

    let info = '';
    if (data.original_size && data.compressed_size) {
        info = `Original: ${data.original_size} → Compressed: ${data.compressed_size} (${data.reduction} reduction)`;
    } else if (data.pages_count) {
        info = `${data.pages_count} pages split successfully`;
    } else if (data.width && data.height) {
        info = `New size: ${data.width} × ${data.height} pixels`;
    } else {
        info = 'File successfully processed!';
    }
    if (resultInfo) resultInfo.textContent = info;

    // Auto scroll to result
    resultArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function showAlert(msg, type = 'info') {
    const existing = document.querySelector('.tool-alert');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.className = `alert alert-${type} tool-alert`;
    div.textContent = msg;
    toolOptions.before(div);
    setTimeout(() => div.remove(), 5000);
}

function resetTool() {
    selectedFiles = [];
    fileList.innerHTML = '';
    fileList.classList.add('hidden');
    toolOptions.classList.add('hidden');
    resultArea.classList.add('hidden');
    progressArea.classList.add('hidden');
    progressBar.style.width = '0%';
    processBtn.disabled = false;
    if (fileInput) fileInput.value = '';
}
