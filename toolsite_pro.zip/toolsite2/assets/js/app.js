/* =========================================
   ToolSite Pro - Main JavaScript
   ========================================= */

const APP_URL = document.querySelector('meta[name="app-url"]')?.content || window.location.origin;

// ---- DARK MODE ----
const darkBtn = document.getElementById('darkModeToggle');
const savedTheme = localStorage.getItem('theme') || 'light';
if (savedTheme === 'dark') document.documentElement.setAttribute('data-theme', 'dark');

darkBtn?.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    darkBtn.querySelector('i').className = next === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
});

// ---- HAMBURGER MENU ----
const hamburger = document.getElementById('hamburger');
const navLinks = document.querySelector('.nav-links');
hamburger?.addEventListener('click', () => {
    navLinks?.classList.toggle('mobile-open');
});

// ---- GLOBAL SEARCH ----
function initSearch(inputId, resultId) {
    const input = document.getElementById(inputId);
    const results = document.getElementById(resultId);
    if (!input || !results) return;

    let timer;
    input.addEventListener('input', () => {
        clearTimeout(timer);
        const q = input.value.trim();
        if (q.length < 2) { results.innerHTML = ''; results.style.display = 'none'; return; }
        timer = setTimeout(async () => {
            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
                const data = await res.json();
                if (!data.tools?.length) { results.style.display = 'none'; return; }
                results.innerHTML = data.tools.map(t => `
                    <a href="/tools/${t.slug}">
                        <i class="fas ${t.icon || 'fa-tools'}"></i>
                        <div><strong>${t.name}</strong><small>${t.description?.substring(0, 50)}...</small></div>
                    </a>`).join('');
                results.style.display = 'block';
            } catch(e) {}
        }, 300);
    });

    document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !results.contains(e.target)) {
            results.style.display = 'none';
        }
    });
}

initSearch('globalSearch', 'searchResults');
initSearch('heroSearch', 'heroSearchResults');

// ---- CATEGORY TABS ----
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tabId = btn.dataset.tab;
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(tabId)?.classList.add('active');
    });
});

// ---- FAQ ACCORDION ----
document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
        const item = btn.closest('.faq-item');
        const isActive = item.classList.contains('active');
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
        if (!isActive) item.classList.add('active');
    });
});

// ---- REVIEWS SLIDER (Simple Auto Scroll) ----
const slider = document.getElementById('reviewsSlider');
if (slider) {
    let scrollAmount = 0;
    setInterval(() => {
        scrollAmount += 320;
        if (scrollAmount >= slider.scrollWidth - slider.clientWidth) scrollAmount = 0;
        slider.scrollTo({ left: scrollAmount, behavior: 'smooth' });
    }, 4000);
}

// ---- STICKY NAVBAR SCROLL ----
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 10) navbar?.classList.add('scrolled');
    else navbar?.classList.remove('scrolled');
});
