<?php
// This file runs via cron job every hour to clean up expired files
// Add to cron: 0 * * * * php /path/to/toolsite2/cron_cleanup.php

require_once __DIR__ . '/config/database.php';

spl_autoload_register(function($class) {
    $paths = [
        __DIR__ . '/app/Helpers/' . $class . '.php',
        __DIR__ . '/app/Models/' . $class . '.php',
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) { require_once $path; return; }
    }
});

$deleted = FileHelper::deleteOldFiles();

// Also clean up split directories
$splitDirs = glob(UPLOAD_PROCESSED_DIR . 'split_*', GLOB_ONLYDIR);
foreach ($splitDirs as $dir) {
    if (time() - filemtime($dir) > FILE_LIFETIME) {
        array_map('unlink', glob($dir . '/*'));
        rmdir($dir);
    }
}

echo date('Y-m-d H:i:s') . " - Cleaned up {$deleted} expired files.\n";
