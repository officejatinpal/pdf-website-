-- =========================================
-- ToolSite Pro - Database Migration
-- Run this file to create all tables
-- =========================================

CREATE DATABASE IF NOT EXISTS toolsite_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toolsite_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NULL,          -- NULL for Google OAuth users
    avatar VARCHAR(255) NULL,
    google_id VARCHAR(100) NULL UNIQUE,
    role ENUM('user', 'admin') DEFAULT 'user',
    is_verified TINYINT(1) DEFAULT 0,
    verification_token VARCHAR(100) NULL,
    reset_token VARCHAR(100) NULL,
    reset_token_expires DATETIME NULL,
    plan ENUM('free', 'pro', 'enterprise') DEFAULT 'free',
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tools Table (all available tools)
CREATE TABLE IF NOT EXISTS tools (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    category ENUM('pdf','image','document','converter') NOT NULL,
    sub_category VARCHAR(50) NULL,
    icon VARCHAR(100) NULL,
    is_active TINYINT(1) DEFAULT 1,
    is_premium TINYINT(1) DEFAULT 0,
    usage_count INT DEFAULT 0,
    sort_order INT DEFAULT 0,
    meta_title VARCHAR(160) NULL,
    meta_description VARCHAR(320) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- File Uploads Table
CREATE TABLE IF NOT EXISTS file_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,                    -- NULL for guest users
    session_id VARCHAR(100) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_type ENUM('pdf','image','document','other') NOT NULL,
    upload_ip VARCHAR(45) NOT NULL,
    is_processed TINYINT(1) DEFAULT 0,
    is_deleted TINYINT(1) DEFAULT 0,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_session (session_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB;

-- Tool Usage / History Table
CREATE TABLE IF NOT EXISTS tool_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    session_id VARCHAR(100) NOT NULL,
    tool_id INT NOT NULL,
    tool_slug VARCHAR(100) NOT NULL,
    input_files TEXT NULL,               -- JSON array of file IDs
    output_file VARCHAR(500) NULL,
    status ENUM('pending','processing','completed','failed') DEFAULT 'pending',
    error_message TEXT NULL,
    processing_time FLOAT NULL,          -- seconds
    ip_address VARCHAR(45) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (tool_id) REFERENCES tools(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Favorite Tools
CREATE TABLE IF NOT EXISTS user_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tool_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_fav (user_id, tool_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (tool_id) REFERENCES tools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Blog Posts
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    excerpt TEXT NULL,
    content LONGTEXT NOT NULL,
    featured_image VARCHAR(500) NULL,
    author_id INT NULL,
    category VARCHAR(100) NULL,
    tags TEXT NULL,                      -- JSON
    status ENUM('draft','published') DEFAULT 'draft',
    views INT DEFAULT 0,
    meta_title VARCHAR(160) NULL,
    meta_description VARCHAR(320) NULL,
    published_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- FAQs
CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    tool_id INT NULL,                    -- NULL = global FAQ
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tool_id) REFERENCES tools(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- User Reviews / Testimonials
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    rating TINYINT NOT NULL DEFAULT 5,
    comment TEXT NOT NULL,
    tool_id INT NULL,
    is_approved TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (tool_id) REFERENCES tools(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Contact Messages
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(255) NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================
-- Seed Data: Tools
-- =========================================
INSERT INTO tools (name, slug, description, category, sub_category, icon, sort_order) VALUES
-- PDF Management
('PDF Merge', 'pdf-merge', 'Multiple PDF files ko ek mein combine karein', 'pdf', 'management', 'fa-object-group', 1),
('PDF Split', 'pdf-split', 'PDF ko multiple files mein divide karein', 'pdf', 'management', 'fa-cut', 2),
('PDF Compress', 'pdf-compress', 'PDF file size kam karein quality maintain karte hue', 'pdf', 'management', 'fa-compress', 3),
('PDF Rotate', 'pdf-rotate', 'PDF pages ko rotate karein', 'pdf', 'management', 'fa-redo', 4),
('Delete PDF Pages', 'pdf-delete-pages', 'PDF se specific pages hatayein', 'pdf', 'management', 'fa-trash', 5),
('Extract PDF Pages', 'pdf-extract-pages', 'PDF se specific pages nikaalein', 'pdf', 'management', 'fa-file-export', 6),
('Add Page Numbers', 'pdf-add-numbers', 'PDF mein page numbers add karein', 'pdf', 'editing', 'fa-list-ol', 7),
('Add Watermark', 'add-watermark', 'PDF mein watermark add karein', 'pdf', 'security', 'fa-water', 8),
('Remove Watermark', 'remove-watermark', 'PDF se watermark hatayein', 'pdf', 'security', 'fa-eraser', 9),
('Lock PDF', 'lock-pdf', 'PDF mein password lagayein', 'pdf', 'security', 'fa-lock', 10),
('Unlock PDF', 'unlock-pdf', 'PDF se password hatayein', 'pdf', 'security', 'fa-unlock', 11),
-- PDF Conversion
('PDF to Word', 'pdf-to-word', 'PDF ko editable Word document mein convert karein', 'pdf', 'conversion', 'fa-file-word', 20),
('Word to PDF', 'word-to-pdf', 'Word document ko PDF mein convert karein', 'pdf', 'conversion', 'fa-file-pdf', 21),
('PDF to JPG', 'pdf-to-jpg', 'PDF pages ko JPG images mein convert karein', 'pdf', 'conversion', 'fa-file-image', 22),
('JPG to PDF', 'jpg-to-pdf', 'JPG images ko PDF mein convert karein', 'pdf', 'conversion', 'fa-images', 23),
('PDF to Excel', 'pdf-to-excel', 'PDF ko Excel spreadsheet mein convert karein', 'pdf', 'conversion', 'fa-file-excel', 24),
('Excel to PDF', 'excel-to-pdf', 'Excel file ko PDF mein convert karein', 'pdf', 'conversion', 'fa-file-pdf', 25),
('PDF to PPT', 'pdf-to-ppt', 'PDF ko PowerPoint mein convert karein', 'pdf', 'conversion', 'fa-file-powerpoint', 26),
('PPT to PDF', 'ppt-to-pdf', 'PowerPoint ko PDF mein convert karein', 'pdf', 'conversion', 'fa-file-pdf', 27),
('PDF to HTML', 'pdf-to-html', 'PDF ko HTML webpage mein convert karein', 'pdf', 'conversion', 'fa-code', 28),
('PDF to TXT', 'pdf-to-txt', 'PDF se text extract karein', 'pdf', 'conversion', 'fa-file-alt', 29),
('PDF OCR', 'pdf-ocr', 'Scanned PDF ko searchable banayein', 'pdf', 'optimization', 'fa-search', 30),
-- Image Tools
('Resize Image', 'resize-image', 'Image ko resize karein custom dimensions mein', 'image', 'editing', 'fa-expand-arrows-alt', 40),
('Compress Image', 'compress-image', 'Image size kam karein quality maintain karte hue', 'image', 'editing', 'fa-compress-arrows-alt', 41),
('Crop Image', 'crop-image', 'Image ko crop karein', 'image', 'editing', 'fa-crop', 42),
('Rotate Image', 'rotate-image', 'Image ko rotate karein', 'image', 'editing', 'fa-sync', 43),
('JPG to PNG', 'jpg-to-png', 'JPG image ko PNG mein convert karein', 'image', 'conversion', 'fa-exchange-alt', 50),
('PNG to JPG', 'png-to-jpg', 'PNG image ko JPG mein convert karein', 'image', 'conversion', 'fa-exchange-alt', 51),
('WEBP to JPG', 'webp-to-jpg', 'WEBP image ko JPG mein convert karein', 'image', 'conversion', 'fa-exchange-alt', 52),
('Background Remover', 'bg-remover', 'Image ka background remove karein AI se', 'image', 'ai', 'fa-magic', 60),
('Image to PDF', 'image-to-pdf', 'Images ko PDF mein convert karein', 'image', 'pdf', 'fa-file-pdf', 70);

-- Seed FAQs
INSERT INTO faqs (question, answer, sort_order) VALUES
('Kya meri files safe hain?', 'Haan, aapki files 100% safe hain. Hamare server par files sirf 1 ghante ke liye store hoti hain aur phir automatically delete ho jaati hain. Hum aapki files kabhi bhi share nahi karte.', 1),
('Kitni badi files upload kar sakta hoon?', 'Free users ke liye maximum 50MB per file allowed hai. Premium users ke liye yeh limit 200MB tak badh jaati hai.', 2),
('Kya mujhe account banana zaroori hai?', 'Nahi! Aap bina account banaye bhi hamare tools use kar sakte hain. Lekin account banane se aapko file history, favorites aur saved files jaise features milte hain.', 3),
('Kitni files ek saath process ho sakti hain?', 'Guest users ek baar mein 5 files upload kar sakte hain. Registered users ke liye yeh 20 files tak ho sakti hai.', 4),
('Kya yeh tools free hain?', 'Haan, hamare basic tools bilkul free hain. Kuch advanced features jaise bulk processing aur cloud storage integration premium plan mein available hain.', 5);

-- Seed Reviews
INSERT INTO reviews (name, rating, comment, is_approved) VALUES
('Rahul Sharma', 5, 'Bahut acha tool hai! PDF merge karna bilkul asaan ho gaya. Recommend karunga sab ko.', 1),
('Priya Singh', 5, 'Image compress karna pehle bahut mushkil tha, ab 2 second mein ho jaata hai. Shukriya!', 1),
('Amit Kumar', 4, 'PDF to Word conversion bahut accurate hai. Kuch minor formatting issues aaye lekin overall bahut achha hai.', 1),
('Sunita Verma', 5, 'Background remover kamaal ka hai! Bilkul professional results deta hai.', 1);

