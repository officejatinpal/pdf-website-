<?php
// Routes Configuration
$routes = [
    // Homepage
    '/' => ['HomeController', 'index'],
    
    // Auth Routes
    '/login' => ['AuthController', 'loginPage'],
    '/register' => ['AuthController', 'registerPage'],
    '/auth/login' => ['AuthController', 'login'],
    '/auth/register' => ['AuthController', 'register'],
    '/auth/logout' => ['AuthController', 'logout'],
    '/auth/google' => ['AuthController', 'googleLogin'],
    '/auth/google/callback' => ['AuthController', 'googleCallback'],
    
    // Dashboard
    '/dashboard' => ['DashboardController', 'index'],
    '/dashboard/history' => ['DashboardController', 'history'],
    '/dashboard/favorites' => ['DashboardController', 'favorites'],
    '/dashboard/saved-files' => ['DashboardController', 'savedFiles'],
    
    // PDF Tools
    '/tools/pdf-merge' => ['PdfController', 'mergePage'],
    '/tools/pdf-split' => ['PdfController', 'splitPage'],
    '/tools/pdf-compress' => ['PdfController', 'compressPage'],
    '/tools/pdf-rotate' => ['PdfController', 'rotatePage'],
    '/tools/pdf-to-word' => ['PdfController', 'pdfToWordPage'],
    '/tools/word-to-pdf' => ['PdfController', 'wordToPdfPage'],
    '/tools/pdf-to-jpg' => ['PdfController', 'pdfToJpgPage'],
    '/tools/jpg-to-pdf' => ['PdfController', 'jpgToPdfPage'],
    '/tools/lock-pdf' => ['PdfController', 'lockPdfPage'],
    '/tools/unlock-pdf' => ['PdfController', 'unlockPdfPage'],
    '/tools/pdf-ocr' => ['PdfController', 'ocrPage'],
    '/tools/add-watermark' => ['PdfController', 'watermarkPage'],
    
    // Image Tools
    '/tools/resize-image' => ['ImageController', 'resizePage'],
    '/tools/compress-image' => ['ImageController', 'compressPage'],
    '/tools/crop-image' => ['ImageController', 'cropPage'],
    '/tools/bg-remover' => ['ImageController', 'bgRemoverPage'],
    '/tools/image-to-pdf' => ['ImageController', 'imageToPdfPage'],
    '/tools/jpg-to-png' => ['ImageController', 'jpgToPngPage'],
    '/tools/png-to-jpg' => ['ImageController', 'pngToJpgPage'],
    
    // API Endpoints
    '/api/pdf/merge' => ['ApiPdfController', 'merge'],
    '/api/pdf/split' => ['ApiPdfController', 'split'],
    '/api/pdf/compress' => ['ApiPdfController', 'compress'],
    '/api/pdf/rotate' => ['ApiPdfController', 'rotate'],
    '/api/pdf/lock' => ['ApiPdfController', 'lock'],
    '/api/pdf/unlock' => ['ApiPdfController', 'unlock'],
    '/api/image/resize' => ['ApiImageController', 'resize'],
    '/api/image/compress' => ['ApiImageController', 'compress'],
    '/api/image/bg-remove' => ['ApiImageController', 'bgRemove'],
    '/api/file/download' => ['ApiFileController', 'download'],
    '/api/file/delete' => ['ApiFileController', 'delete'],
    
    // Blog
    '/blog' => ['BlogController', 'index'],
    '/blog/{slug}' => ['BlogController', 'show'],
    
    // Static pages
    '/privacy-policy' => ['PageController', 'privacy'],
    '/terms' => ['PageController', 'terms'],
    '/about' => ['PageController', 'about'],
    '/contact' => ['PageController', 'contact'],
];

return $routes;
