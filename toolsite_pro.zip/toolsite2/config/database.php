<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'toolsite_db');
define('DB_USER', 'root');          // Change to your DB username
define('DB_PASS', '');              // Change to your DB password
define('DB_CHARSET', 'utf8mb4');

// App Configuration
define('APP_NAME', 'ToolSite Pro');
define('APP_URL', 'http://localhost/toolsite2'); // Change for live
define('APP_VERSION', '1.0.0');
define('APP_ENV', 'development'); // 'development' or 'production'
define('APP_DEBUG', true);         // false in production

// Upload Configuration
define('UPLOAD_MAX_SIZE', 50 * 1024 * 1024); // 50MB
define('UPLOAD_TEMP_DIR', __DIR__ . '/../uploads/temp/');
define('UPLOAD_PROCESSED_DIR', __DIR__ . '/../uploads/processed/');
define('FILE_LIFETIME', 3600); // 1 hour = 3600 seconds

// Session
define('SESSION_LIFETIME', 86400); // 24 hours

// Google OAuth (optional)
define('GOOGLE_CLIENT_ID', '');
define('GOOGLE_CLIENT_SECRET', '');
define('GOOGLE_REDIRECT_URI', APP_URL . '/auth/google/callback');

// Allowed file types
define('ALLOWED_PDF', ['application/pdf']);
define('ALLOWED_IMAGE', ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']);
define('ALLOWED_DOCUMENT', ['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain', 'text/html', 'application/epub+zip']);
